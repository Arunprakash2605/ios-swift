import SwiftUI

/// Root authenticated container displaying the active tab content above the custom `BottomNavigationBar`.
struct MainTabView: View {
    @Environment(AppState.self) private var appState

    var body: some View {
        @Bindable var bindableState = appState

        ZStack(alignment: .bottom) {
            Group {
                switch appState.selectedTab {
                case .home:
                    DashboardView()
                case .pets:
                    PetListView()
                case .care:
                    CareListView()
                case .profile:
                    ProfileView()
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)

            BottomNavigationBar(selectedTab: $bindableState.selectedTab)
        }
        .ignoresSafeArea(.keyboard, edges: .bottom)
    }
}
