import Foundation
import Observation

/// Handles biometric availability checks, LocalAuthentication sign-in, and manual credential validation.
@MainActor
@Observable
final class AuthenticationViewModel {
    enum AuthMode: String, CaseIterable, Identifiable {
        case signIn = "Sign In"
        case register = "Create Account"

        var id: String { rawValue }
    }

    var authMode: AuthMode = .signIn
    var showManualLogin: Bool = false

    // Form fields
    var fullName: String = ""
    var email: String = ""
    var password: String = ""

    // Validation & feedback
    var nameError: String?
    var emailError: String?
    var passwordError: String?
    var generalErrorMessage: String?
    var biometricStatusMessage: String?

    var isAuthenticating: Bool = false
    var biometricCapability: BiometricCapability = .unavailable("Checking biometric hardware...")

    private let appState: AppState

    init(appState: AppState) {
        self.appState = appState
        refreshBiometricAvailability()
        // If biometrics are disabled or unavailable, default straight to manual login while keeping toggle accessible.
        if !appState.isBiometricEnabled || !biometricCapability.isAvailable {
            self.showManualLogin = true
        }
    }

    var isBiometricAvailable: Bool {
        biometricCapability.isAvailable && appState.isBiometricEnabled
    }

    /// Queries Apple's `LocalAuthentication` framework for current Face ID / Touch ID availability.
    func refreshBiometricAvailability() {
        biometricCapability = appState.biometricService.checkAvailability()
        if !appState.isBiometricEnabled {
            biometricStatusMessage = "Biometric login is currently disabled in Profile settings."
        } else if let reason = biometricCapability.unavailableReason {
            biometricStatusMessage = reason
        } else {
            biometricStatusMessage = "\(biometricCapability.displayName) is ready to unlock PetCare."
        }
    }

    /// Triggers real biometric evaluation via `BiometricService`.
    func authenticateWithBiometrics() async {
        refreshBiometricAvailability()
        generalErrorMessage = nil

        guard appState.isBiometricEnabled else {
            generalErrorMessage = "Biometric login is disabled in your profile settings. Please sign in manually."
            return
        }

        guard biometricCapability.isAvailable else {
            generalErrorMessage = biometricCapability.unavailableReason ?? "Biometric authentication is unavailable."
            return
        }

        isAuthenticating = true
        let result = await appState.biometricService.authenticate(
            reason: "Authenticate to access \(AppConstants.AppInfo.name) records"
        )
        isAuthenticating = false

        switch result {
        case .success:
            let user = appState.storageService.loadUser()
            appState.completeAuthentication(for: user)
        case .failure(let error):
            switch error {
            case .fallbackRequested:
                generalErrorMessage = error.localizedDescription
                showManualLogin = true
            case .cancelled:
                biometricStatusMessage = error.localizedDescription
            case .unavailable, .failed:
                generalErrorMessage = error.localizedDescription
            }
        }
    }

    /// Validates manual credentials and signs in or creates a local user account.
    func submitManualAuthentication() {
        clearValidationErrors()

        let trimmedEmail = email.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedName = fullName.trimmingCharacters(in: .whitespacesAndNewlines)
        var isValid = true

        if authMode == .register && trimmedName.isEmpty {
            nameError = "Please enter your full name."
            isValid = false
        }

        if trimmedEmail.isEmpty {
            emailError = "Email address is required."
            isValid = false
        } else if !isValidEmail(trimmedEmail) {
            emailError = "Please enter a valid email address."
            isValid = false
        }

        if password.isEmpty {
            passwordError = "Password is required."
            isValid = false
        } else if password.count < AppConstants.Validation.minimumPasswordLength {
            passwordError = "Password must be at least \(AppConstants.Validation.minimumPasswordLength) characters."
            isValid = false
        }

        guard isValid else { return }

        let submittedHash = User.hashPassword(password)

        switch authMode {
        case .signIn:
            let storedUser = appState.storageService.loadUser()
            let emailMatches = storedUser.email.caseInsensitiveCompare(trimmedEmail) == .orderedSame
            let passwordMatches = storedUser.passwordHash == submittedHash

            guard emailMatches && passwordMatches else {
                generalErrorMessage = "Invalid email or password. Please verify your credentials."
                return
            }

            appState.completeAuthentication(for: storedUser)
            password = ""

        case .register:
            let newUser = User(
                fullName: trimmedName,
                email: trimmedEmail.lowercased(),
                passwordHash: submittedHash
            )
            appState.completeAuthentication(for: newUser)
            password = ""
        }
    }

    /// Populates the default demo account credentials so the user can test manual validation & login easily.
    func fillDemoCredentials() {
        authMode = .signIn
        clearValidationErrors()
        email = AppConstants.DefaultAccount.email
        password = AppConstants.DefaultAccount.password
    }

    func switchMode(to mode: AuthMode) {
        authMode = mode
        clearValidationErrors()
    }

    private func clearValidationErrors() {
        nameError = nil
        emailError = nil
        passwordError = nil
        generalErrorMessage = nil
    }

    private func isValidEmail(_ value: String) -> Bool {
        let predicate = NSPredicate(format: "SELF MATCHES %@", AppConstants.Validation.emailRegex)
        return predicate.evaluate(with: value)
    }
}
