import SwiftUI

/// Reusable form text field with icon, optional secure toggle, and inline validation feedback.
struct CustomTextField: View {
    let title: String
    let placeholder: String
    @Binding var text: String
    var icon: String? = nil
    var isSecure: Bool = false
    var keyboardType: UIKeyboardType = .default
    var autocapitalization: TextInputAutocapitalization = .sentences
    var errorMessage: String? = nil

    @State private var isRevealed = false
    @FocusState private var isFocused: Bool

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(AppColors.textSecondary)

            HStack(spacing: 10) {
                if let icon {
                    Image(systemName: icon)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundStyle(isFocused ? AppColors.primary : AppColors.textTertiary)
                        .frame(width: 20)
                }

                Group {
                    if isSecure && !isRevealed {
                        SecureField(placeholder, text: $text)
                    } else {
                        TextField(placeholder, text: $text)
                            .keyboardType(keyboardType)
                            .textInputAutocapitalization(autocapitalization)
                    }
                }
                .font(.system(size: 15, weight: .regular))
                .foregroundStyle(AppColors.textPrimary)
                .autocorrectionDisabled(keyboardType == .emailAddress || isSecure)
                .focused($isFocused)

                if isSecure {
                    Button {
                        isRevealed.toggle()
                    } label: {
                        Image(systemName: isRevealed ? "eye.slash.fill" : "eye.fill")
                            .font(.system(size: 14, weight: .medium))
                            .foregroundStyle(AppColors.textTertiary)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel(isRevealed ? "Hide password" : "Show password")
                }
            }
            .padding(.horizontal, 14)
            .frame(height: 48)
            .background(AppColors.inputBackground)
            .clipShape(RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous)
                    .stroke(strokeColor, lineWidth: isFocused || hasError ? 1.5 : 1)
            )

            if let errorMessage, !errorMessage.isEmpty {
                Label(errorMessage, systemImage: "exclamationmark.circle.fill")
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(AppColors.error)
                    .transition(.opacity)
            }
        }
        .animation(.easeInOut(duration: 0.15), value: errorMessage)
    }

    private var hasError: Bool {
        guard let errorMessage else { return false }
        return !errorMessage.isEmpty
    }

    private var strokeColor: Color {
        if hasError { return AppColors.error }
        if isFocused { return AppColors.primary }
        return AppColors.border
    }
}
