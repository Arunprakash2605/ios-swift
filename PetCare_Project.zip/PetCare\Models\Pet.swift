import Foundation
import SwiftData

/// Supported pet species in PetCare.
enum PetType: String, CaseIterable, Codable, Identifiable {
    case dog = "Dog"
    case cat = "Cat"
    case bird = "Bird"
    case rabbit = "Rabbit"
    case other = "Other"

    var id: String { rawValue }

    var iconName: String {
        switch self {
        case .dog: return "dog.fill"
        case .cat: return "cat.fill"
        case .bird: return "bird.fill"
        case .rabbit: return "hare.fill"
        case .other: return "pawprint.fill"
        }
    }

    /// Corresponding lightweight image asset in Assets.xcassets.
    var assetImageName: String {
        switch self {
        case .dog: return "PetDog"
        case .cat: return "PetCat"
        case .bird: return "PetBird"
        case .rabbit: return "PetRabbit"
        case .other: return "PetOther"
        }
    }
}

/// Biological sex options for a registered pet.
enum PetGender: String, CaseIterable, Codable, Identifiable {
    case male = "Male"
    case female = "Female"
    case unknown = "Unknown"

    var id: String { rawValue }
}

/// Persistent SwiftData model representing a registered pet.
@Model
final class Pet {
    @Attribute(.unique) var id: UUID
    var name: String
    var petTypeRaw: String
    var breed: String
    var age: Double
    var genderRaw: String
    var weight: Double
    @Attribute(.externalStorage) var profileImageData: Data?
    var createdAt: Date

    @Relationship(deleteRule: .cascade, inverse: \CareEntry.pet)
    var careEntries: [CareEntry] = []

    init(
        id: UUID = UUID(),
        name: String,
        petType: PetType,
        breed: String,
        age: Double,
        gender: PetGender,
        weight: Double,
        profileImageData: Data? = nil,
        createdAt: Date = Date()
    ) {
        self.id = id
        self.name = name
        self.petTypeRaw = petType.rawValue
        self.breed = breed
        self.age = age
        self.genderRaw = gender.rawValue
        self.weight = weight
        self.profileImageData = profileImageData
        self.createdAt = createdAt
    }

    var petType: PetType {
        get { PetType(rawValue: petTypeRaw) ?? .other }
        set { petTypeRaw = newValue.rawValue }
    }

    var gender: PetGender {
        get { PetGender(rawValue: genderRaw) ?? .unknown }
        set { genderRaw = newValue.rawValue }
    }

    /// Cleanly formatted age label (months when under 1 year, years otherwise).
    var formattedAge: String {
        if age < 1.0 {
            let months = max(1, Int((age * 12).rounded()))
            return months == 1 ? "1 mo" : "\(months) mos"
        }
        if age.truncatingRemainder(dividingBy: 1) == 0 {
            let years = Int(age)
            return years == 1 ? "1 yr" : "\(years) yrs"
        }
        return String(format: "%.1f yrs", age)
    }

    /// Cleanly formatted weight in kilograms.
    var formattedWeight: String {
        if weight.truncatingRemainder(dividingBy: 1) == 0 {
            return "\(Int(weight)) kg"
        }
        return String(format: "%.1f kg", weight)
    }
}
