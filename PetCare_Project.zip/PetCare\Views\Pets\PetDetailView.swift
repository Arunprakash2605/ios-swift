import SwiftUI

/// Detailed pet profile displaying attributes, care history, edit action, and delete confirmation.
struct PetDetailView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss

    let petId: UUID

    @State private var viewModel: PetViewModel?
    @State private var showEditSheet = false
    @State private var showAddCareSheet = false
    @State private var showDeleteAlert = false

    private var pet: Pet? {
        viewModel?.pet(withId: petId)
    }

    var body: some View {
        Group {
            if let pet, let viewModel {
                let entries = viewModel.careEntries(for: pet)

                ScrollView(showsIndicators: false) {
                    VStack(spacing: 18) {
                        profileHeaderCard(pet: pet)
                        attributesGrid(pet: pet)
                        careHistorySection(pet: pet, entries: entries)
                        actionButtons(pet: pet, viewModel: viewModel)
                    }
                    .padding(.horizontal, AppConstants.Layout.screenPadding)
                    .padding(.top, 12)
                    .padding(.bottom, AppConstants.Layout.bottomBarClearance)
                }
                .background(AppColors.background.ignoresSafeArea())
                .navigationTitle(pet.name)
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Edit") {
                            showEditSheet = true
                        }
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(AppColors.primaryDark)
                    }
                }
                .sheet(isPresented: $showEditSheet) {
                    EditPetView(pet: pet)
                }
                .sheet(isPresented: $showAddCareSheet) {
                    AddCareView(preselectedPetId: pet.id)
                }
                .alert("Delete \(pet.name)?", isPresented: $showDeleteAlert) {
                    Button("Cancel", role: .cancel) {}
                    Button("Delete", role: .destructive) {
                        if viewModel.deletePet(pet) {
                            dismiss()
                        }
                    }
                } message: {
                    Text("This will permanently remove \(pet.name) and all associated care and vaccination records.")
                }
            } else {
                EmptyStateView(
                    icon: "pawprint.slash",
                    title: "Pet Not Found",
                    message: "This pet profile may have been deleted."
                )
                .padding()
                .background(AppColors.background.ignoresSafeArea())
            }
        }
        .onAppear {
            if viewModel == nil {
                viewModel = PetViewModel(appState: appState)
            }
        }
    }

    private func profileHeaderCard(pet: Pet) -> some View {
        VStack(spacing: 14) {
            PetThumbnailView(
                petType: pet.petType,
                imageData: pet.profileImageData,
                size: 104,
                cornerRadius: 26
            )

            VStack(spacing: 4) {
                Text(pet.name)
                    .font(.system(size: 24, weight: .bold, design: .rounded))
                    .foregroundStyle(AppColors.textPrimary)

                Text("\(pet.breed) • \(pet.petType.rawValue)")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(AppColors.textSecondary)
            }
        }
        .frame(maxWidth: .infinity)
        .petCareCard(padding: 20)
    }

    private func attributesGrid(pet: Pet) -> some View {
        HStack(spacing: 10) {
            AttributeTile(title: "Age", value: pet.formattedAge, icon: "birthday.cake.fill")
            AttributeTile(title: "Gender", value: pet.gender.rawValue, icon: "figure.stand")
            AttributeTile(title: "Weight", value: pet.formattedWeight, icon: "scalemass.fill")
        }
    }

    private func careHistorySection(pet: Pet, entries: [CareEntry]) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Care & Vaccinations")
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundStyle(AppColors.textPrimary)

                Spacer()

                Button {
                    showAddCareSheet = true
                } label: {
                    Label("Add Care", systemImage: "plus.circle.fill")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(AppColors.primaryDark)
                }
            }

            if entries.isEmpty {
                EmptyStateView(
                    icon: "cross.case",
                    title: "No Care Records",
                    message: "Add a vaccination, vet checkup, grooming, or diet plan for \(pet.name).",
                    actionTitle: "Add Care Entry"
                ) {
                    showAddCareSheet = true
                }
            } else {
                VStack(spacing: 10) {
                    ForEach(entries, id: \.id) { entry in
                        NavigationLink {
                            CareDetailView(entryId: entry.id)
                        } label: {
                            CareRowView(entry: entry)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    private func actionButtons(pet: Pet, viewModel: PetViewModel) -> some View {
        VStack(spacing: 10) {
            CustomButton(title: "Edit Pet Information", icon: "pencil", style: .secondary) {
                showEditSheet = true
            }

            CustomButton(title: "Delete Pet", icon: "trash.fill", style: .destructive) {
                showDeleteAlert = true
            }
        }
        .padding(.top, 4)
    }
}

private struct AttributeTile: View {
    let title: String
    let value: String
    let icon: String

    var body: some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 16, weight: .semibold))
                .foregroundStyle(AppColors.primary)

            Text(value)
                .font(.system(size: 15, weight: .bold, design: .rounded))
                .foregroundStyle(AppColors.textPrimary)

            Text(title)
                .font(.system(size: 11, weight: .medium))
                .foregroundStyle(AppColors.textSecondary)
        }
        .frame(maxWidth: .infinity)
        .petCareCard(padding: 12)
    }
}
