import Foundation
import CoreGraphics

/// Application-wide constants, layout metrics, storage keys, and validation rules.
enum AppConstants {
    enum AppInfo {
        static let name = "PetCare"
        static let subtitle = "Pet Care & Vaccination Tracker"
        static let version = "1.0.0"
        static let build = "1"
        static let bundleIdentifier = "com.petcare.app"
    }

    enum Layout {
        static let screenPadding: CGFloat = 16
        static let cardPadding: CGFloat = 16
        static let cardCornerRadius: CGFloat = 18
        static let buttonCornerRadius: CGFloat = 14
        static let inputCornerRadius: CGFloat = 12
        static let badgeCornerRadius: CGFloat = 10
        static let sectionSpacing: CGFloat = 20
        static let itemSpacing: CGFloat = 12
        static let bottomBarClearance: CGFloat = 96
    }

    enum StorageKeys {
        static let hasSeededInitialData = "petcare.hasSeededInitialData"
        static let userProfileData = "petcare.userProfileData"
        static let biometricEnabled = "petcare.biometricEnabled"
        static let notificationsEnabled = "petcare.notificationsEnabled"
        static let reminderHourOffset = "petcare.reminderDayOffset"
        static let isAuthenticatedSession = "petcare.isAuthenticatedSession"
    }

    enum Notifications {
        static let categoryIdentifier = "PETCARE_REMINDER"
        static let reminderPrefix = "petcare-entry-"
        /// Default reminder lead time: 1 day (24 hours) before scheduled care, plus same-morning fallback.
        static let defaultLeadSeconds: TimeInterval = 24 * 60 * 60
        static let morningHour = 9
        static let morningMinute = 0
    }

    enum Validation {
        static let minimumPasswordLength = 6
        static let emailRegex = #"^[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,64}$"#
    }

    enum DefaultAccount {
        static let name = "Alex Taylor"
        static let email = "owner@petcare.app"
        static let password = "PetCare123"
    }
}
