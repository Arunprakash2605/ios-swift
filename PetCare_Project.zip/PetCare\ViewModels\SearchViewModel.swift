import Foundation
import Observation

/// Manages dynamic search and multi-criteria filtering across care and vaccination entries.
@MainActor
@Observable
final class SearchViewModel {
    private let appState: AppState

    var searchQuery: String = ""
    var selectedCategory: CareCategory? = nil   // nil represents "All"
    var selectedStatus: CareStatus? = nil       // nil represents "All"

    init(appState: AppState) {
        self.appState = appState
    }

    var hasActiveFilters: Bool {
        !searchQuery.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ||
        selectedCategory != nil ||
        selectedStatus != nil
    }

    /// Dynamically filtered and sorted care records.
    var filteredEntries: [CareEntry] {
        let query = searchQuery.trimmingCharacters(in: .whitespacesAndNewlines)

        return appState.careEntries
            .filter { entry in
                if let selectedCategory, entry.category != selectedCategory {
                    return false
                }
                if let selectedStatus, entry.status != selectedStatus {
                    return false
                }
                if !query.isEmpty {
                    let matchesTitle = entry.title.localizedCaseInsensitiveContains(query)
                    let matchesPet = entry.petName.localizedCaseInsensitiveContains(query)
                    return matchesTitle || matchesPet
                }
                return true
            }
            .sorted { lhs, rhs in
                if lhs.status != rhs.status {
                    return sortRank(for: lhs.status) < sortRank(for: rhs.status)
                }
                return lhs.scheduledDate < rhs.scheduledDate
            }
    }

    func clearFilters() {
        searchQuery = ""
        selectedCategory = nil
        selectedStatus = nil
    }

    private func sortRank(for status: CareStatus) -> Int {
        switch status {
        case .overdue: return 0
        case .scheduled: return 1
        case .completed: return 2
        }
    }
}
