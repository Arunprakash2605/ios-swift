import SwiftUI
import PhotosUI

/// Modal form for registering a new pet with validation and optional photo upload.
struct AddPetView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss

    @State private var viewModel: PetViewModel?
    @State private var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                if let viewModel {
                    PetFormContent(
                        viewModel: viewModel,
                        selectedPhotoItem: $selectedPhotoItem
                    )
                    .padding(AppConstants.Layout.screenPadding)
                }
            }
            .background(AppColors.background.ignoresSafeArea())
            .navigationTitle("Add New Pet")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                    .foregroundStyle(AppColors.textSecondary)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if viewModel?.addPet() == true {
                            dismiss()
                        }
                    }
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(AppColors.primaryDark)
                }
            }
        }
        .onAppear {
            if viewModel == nil {
                viewModel = PetViewModel(appState: appState)
            }
        }
        .onChange(of: selectedPhotoItem) { _, newItem in
            guard let newItem else { return }
            Task {
                if let data = try? await newItem.loadTransferable(type: Data.self) {
                    viewModel?.profileImageData = data
                }
            }
        }
    }
}

/// Shared form body used by both `AddPetView` and `EditPetView` to avoid duplicating validation UI.
struct PetFormContent: View {
    @Bindable var viewModel: PetViewModel
    @Binding var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        VStack(spacing: 18) {
            // Photo Picker Preview
            VStack(spacing: 12) {
                PetThumbnailView(
                    petType: viewModel.petType,
                    imageData: viewModel.profileImageData,
                    size: 96,
                    cornerRadius: 24
                )

                HStack(spacing: 12) {
                    PhotosPicker(selection: $selectedPhotoItem, matching: .images) {
                        Label(
                            viewModel.profileImageData == nil ? "Choose Photo" : "Change Photo",
                            systemImage: "photo.on.rectangle"
                        )
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(AppColors.primaryDark)
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(AppColors.secondary)
                        .clipShape(Capsule())
                    }

                    if viewModel.profileImageData != nil {
                        Button("Use Default") {
                            viewModel.profileImageData = nil
                            selectedPhotoItem = nil
                        }
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(AppColors.textSecondary)
                    }
                }
            }
            .frame(maxWidth: .infinity)
            .petCareCard(padding: 18)

            // Input Fields Card
            VStack(spacing: 16) {
                CustomTextField(
                    title: "Pet Name *",
                    placeholder: "e.g. Milo",
                    text: $viewModel.name,
                    icon: "pawprint.fill",
                    autocapitalization: .words,
                    errorMessage: viewModel.nameError
                )

                VStack(alignment: .leading, spacing: 6) {
                    Text("Pet Type *")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(AppColors.textSecondary)

                    Picker("Pet Type", selection: $viewModel.petType) {
                        ForEach(PetType.allCases) { type in
                            Label(type.rawValue, systemImage: type.iconName).tag(type)
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                    .frame(height: 46)
                    .background(AppColors.inputBackground)
                    .clipShape(RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous)
                            .stroke(AppColors.border, lineWidth: 1)
                    )
                }

                CustomTextField(
                    title: "Breed *",
                    placeholder: "e.g. Golden Retriever",
                    text: $viewModel.breed,
                    icon: "tag.fill",
                    autocapitalization: .words,
                    errorMessage: viewModel.breedError
                )

                HStack(alignment: .top, spacing: 12) {
                    CustomTextField(
                        title: "Age (Years) *",
                        placeholder: "e.g. 2.5",
                        text: $viewModel.ageText,
                        icon: "birthday.cake.fill",
                        keyboardType: .decimalPad,
                        errorMessage: viewModel.ageError
                    )

                    CustomTextField(
                        title: "Weight (kg) *",
                        placeholder: "e.g. 12.0",
                        text: $viewModel.weightText,
                        icon: "scalemass.fill",
                        keyboardType: .decimalPad,
                        errorMessage: viewModel.weightError
                    )
                }

                VStack(alignment: .leading, spacing: 6) {
                    Text("Gender")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(AppColors.textSecondary)

                    Picker("Gender", selection: $viewModel.gender) {
                        ForEach(PetGender.allCases) { option in
                            Text(option.rawValue).tag(option)
                        }
                    }
                    .pickerStyle(.segmented)
                }

                if let generalError = viewModel.generalErrorMessage {
                    Text(generalError)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(AppColors.error)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .petCareCard(padding: 18)
        }
    }
}
