import Foundation

/// Date formatting and calendar calculation helpers used across dashboards, care lists, and status tracking.
extension Date {
    private static let displayDateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .none
        return formatter
    }()

    private static let displayDateTimeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        return formatter
    }()

    private static let headerDateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEEE, MMM d"
        return formatter
    }()

    private static let shortTimeFormatter: DateFormatter = {
        let formatter = DateFormatter()
        formatter.timeStyle = .short
        formatter.dateStyle = .none
        return formatter
    }()

    /// Formatted medium date string, e.g. "Nov 27, 2026".
    var formattedMediumDate: String {
        Date.displayDateFormatter.string(from: self)
    }

    /// Formatted date and time string, e.g. "Nov 27, 2026 at 10:30 AM".
    var formattedDateAndTime: String {
        Date.displayDateTimeFormatter.string(from: self)
    }

    /// Formatted dashboard header string, e.g. "Friday, Nov 27".
    var formattedHeaderDate: String {
        Date.headerDateFormatter.string(from: self)
    }

    /// Formatted time string, e.g. "10:30 AM".
    var formattedShortTime: String {
        Date.shortTimeFormatter.string(from: self)
    }

    /// Start of the calendar day for consistent day-level due/overdue comparisons.
    var startOfDay: Date {
        Calendar.current.startOfDay(for: self)
    }

    /// Returns true when the date falls on the same calendar day as today.
    var isToday: Bool {
        Calendar.current.isDateInToday(self)
    }

    /// Returns true when the calendar day is strictly before today's start of day.
    var isPastDay: Bool {
        startOfDay < Date().startOfDay
    }

    /// Returns true when the calendar day is today or in the future.
    var isTodayOrFuture: Bool {
        startOfDay >= Date().startOfDay
    }

    /// Human-readable relative day label for upcoming cards.
    var relativeScheduleLabel: String {
        let calendar = Calendar.current
        if calendar.isDateInToday(self) {
            return "Today, \(formattedShortTime)"
        }
        if calendar.isDateInTomorrow(self) {
            return "Tomorrow, \(formattedShortTime)"
        }
        if calendar.isDateInYesterday(self) {
            return "Yesterday"
        }
        return formattedMediumDate
    }

    /// Convenience helper to create a date offset by days from now at a specific hour.
    static func offsetFromToday(days: Int, hour: Int = 10, minute: Int = 0) -> Date {
        let calendar = Calendar.current
        let baseDay = calendar.date(byAdding: .day, value: days, to: Date().startOfDay) ?? Date()
        return calendar.date(bySettingHour: hour, minute: minute, second: 0, of: baseDay) ?? baseDay
    }
}
