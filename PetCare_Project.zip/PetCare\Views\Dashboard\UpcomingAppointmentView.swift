import SwiftUI

/// Card representing an upcoming or due care appointment on the Dashboard.
struct UpcomingAppointmentView: View {
    let entry: CareEntry

    var body: some View {
        HStack(spacing: 12) {
            PetThumbnailView(
                petType: entry.pet?.petType ?? .other,
                imageData: entry.pet?.profileImageData,
                size: 54,
                cornerRadius: 15
            )

            VStack(alignment: .leading, spacing: 5) {
                HStack(alignment: .top, spacing: 8) {
                    Text(entry.title)
                        .font(.system(size: 15, weight: .bold, design: .rounded))
                        .foregroundStyle(AppColors.textPrimary)
                        .lineLimit(1)

                    Spacer(minLength: 4)

                    StatusBadge(status: entry.status, compact: true)
                }

                HStack(spacing: 6) {
                    Image(systemName: "pawprint.fill")
                        .font(.system(size: 11))
                        .foregroundStyle(AppColors.primary)
                    Text(entry.petName)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(AppColors.textPrimary)

                    Text("•")
                        .foregroundStyle(AppColors.textTertiary)

                    Text(entry.category.rawValue)
                        .font(.system(size: 12, weight: .medium))
                        .foregroundStyle(entry.category.tintColor)
                }

                HStack(spacing: 12) {
                    Label(entry.scheduledDate.relativeScheduleLabel, systemImage: "calendar")
                        .lineLimit(1)
                    Label(entry.vetClinicName, systemImage: "cross.case")
                        .lineLimit(1)
                }
                .font(.system(size: 12, weight: .regular))
                .foregroundStyle(AppColors.textSecondary)
            }
        }
        .petCareCard(padding: 14)
    }
}
