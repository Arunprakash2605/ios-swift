import Foundation
import Observation
import UserNotifications

/// Global application coordinator holding shared services, authentication session, and live persisted state.
@MainActor
@Observable
final class AppState {
    let storageService: StorageService
    let biometricService: BiometricService
    let notificationService: NotificationService

    var isAuthenticated: Bool = false
    var currentUser: User
    var selectedTab: AppTab = .home

    var pets: [Pet] = []
    var careEntries: [CareEntry] = []

    var isBiometricEnabled: Bool
    var notificationsEnabled: Bool
    var notificationAuthorizationStatus: UNAuthorizationStatus = .notDetermined
    var pendingNotificationCount: Int = 0
    var storageErrorMessage: String?

    init(
        storageService: StorageService? = nil,
        biometricService: BiometricService = BiometricService(),
        notificationService: NotificationService? = nil
    ) {
        let resolvedStorage = storageService ?? StorageService()
        let resolvedNotifications = notificationService ?? NotificationService()

        self.storageService = resolvedStorage
        self.biometricService = biometricService
        self.notificationService = resolvedNotifications

        self.currentUser = resolvedStorage.loadUser()
        self.isBiometricEnabled = resolvedStorage.isBiometricLoginEnabled
        self.notificationsEnabled = resolvedStorage.areNotificationsEnabled

        resolvedStorage.seedInitialDataIfNeeded()
        reloadAllData()

        Task {
            await refreshNotificationState()
        }
    }

    /// Reloads pets and care entries from SwiftData and updates date-driven statuses.
    func reloadAllData() {
        do {
            pets = try storageService.fetchPets()
            careEntries = try storageService.fetchCareEntries()
            storageErrorMessage = nil
        } catch {
            storageErrorMessage = error.localizedDescription
        }
    }

    /// Re-evaluates automatic care statuses (`Scheduled` vs `Overdue`) without overwriting `Completed`.
    func refreshCareStatuses() {
        var didChange = false
        for entry in careEntries where entry.refreshAutomaticStatus() {
            didChange = true
        }
        if didChange {
            do {
                try storageService.saveContext()
            } catch {
                storageErrorMessage = error.localizedDescription
            }
        }
    }

    /// Marks the session as authenticated and refreshes dashboard/notification data.
    func completeAuthentication(for user: User) {
        currentUser = user
        storageService.saveUser(user)
        isAuthenticated = true
        selectedTab = .home
        reloadAllData()
        Task {
            await requestNotificationPermissionOnFirstSignInIfNeeded()
            await syncAllNotifications()
        }
    }

    /// Signs out of the current session and returns to the authentication screen.
    func signOut() {
        isAuthenticated = false
        selectedTab = .home
    }

    func setBiometricEnabled(_ enabled: Bool) {
        isBiometricEnabled = enabled
        storageService.isBiometricLoginEnabled = enabled
    }

    func setNotificationsEnabled(_ enabled: Bool) async {
        if enabled {
            let status = await notificationService.getAuthorizationStatus()
            if status == .notDetermined {
                let granted = await notificationService.requestAuthorization()
                notificationsEnabled = granted
            } else if status == .denied {
                notificationsEnabled = false
            } else {
                notificationsEnabled = true
            }
        } else {
            notificationsEnabled = false
        }

        storageService.areNotificationsEnabled = notificationsEnabled
        await syncAllNotifications()
    }

    func requestNotificationPermissionOnFirstSignInIfNeeded() async {
        let status = await notificationService.getAuthorizationStatus()
        notificationAuthorizationStatus = status
        if status == .notDetermined && notificationsEnabled {
            let granted = await notificationService.requestAuthorization()
            notificationsEnabled = granted
            storageService.areNotificationsEnabled = granted
        }
        await refreshNotificationState()
    }

    func syncAllNotifications() async {
        await notificationService.syncAllReminders(
            entries: careEntries,
            notificationsEnabled: notificationsEnabled
        )
        await refreshNotificationState()
    }

    func refreshNotificationState() async {
        notificationAuthorizationStatus = await notificationService.getAuthorizationStatus()
        pendingNotificationCount = await notificationService.pendingReminderCount()
    }
}
