import Foundation
import UserNotifications

/// Manages local notifications for upcoming vaccinations and pet care appointments.
@MainActor
final class NotificationService {
    private let center = UNUserNotificationCenter.current()

    /// Checks the current system notification permission status.
    func getAuthorizationStatus() async -> UNAuthorizationStatus {
        let settings = await center.notificationSettings()
        return settings.authorizationStatus
    }

    /// Requests user permission to show alerts, badges, and sounds.
    func requestAuthorization() async -> Bool {
        do {
            return try await center.requestAuthorization(options: [.alert, .sound, .badge])
        } catch {
            return false
        }
    }

    /// Schedules a local reminder for an upcoming care entry without duplicating existing requests.
    func scheduleReminder(for entry: CareEntry, notificationsEnabled: Bool) async {
        let identifier = notificationIdentifier(for: entry.id)

        // Always remove any stale notification for this entry first to prevent duplicates.
        center.removePendingNotificationRequests(withIdentifiers: [identifier])

        guard notificationsEnabled else { return }
        guard entry.status == .scheduled else { return }

        let status = await getAuthorizationStatus()
        guard status == .authorized || status == .provisional else { return }

        // Fire 24 hours before the appointment when possible, or 5 seconds/next available moment if today.
        let leadFireDate = entry.scheduledDate.addingTimeInterval(-AppConstants.Notifications.defaultLeadSeconds)
        let now = Date()
        let targetDate: Date

        if leadFireDate > now {
            targetDate = leadFireDate
        } else if entry.scheduledDate > now {
            targetDate = entry.scheduledDate
        } else {
            return
        }

        let content = UNMutableNotificationContent()
        content.title = entry.category == .vaccination
            ? "Upcoming Vaccination: \(entry.petName)"
            : "PetCare Reminder: \(entry.petName)"
        content.body = "\(entry.title) at \(entry.vetClinicName) on \(entry.scheduledDate.formattedDateAndTime)."
        content.sound = .default
        content.categoryIdentifier = AppConstants.Notifications.categoryIdentifier
        content.userInfo = [
            "careEntryId": entry.id.uuidString,
            "category": entry.category.rawValue
        ]

        let triggerComponents = Calendar.current.dateComponents(
            [.year, .month, .day, .hour, .minute, .second],
            from: targetDate
        )
        let trigger = UNCalendarNotificationTrigger(dateMatching: triggerComponents, repeats: false)
        let request = UNNotificationRequest(identifier: identifier, content: content, trigger: trigger)

        try? await center.add(request)
    }

    /// Cancels any scheduled reminder associated with a care entry ID.
    func cancelReminder(for entryId: UUID) {
        let identifier = notificationIdentifier(for: entryId)
        center.removePendingNotificationRequests(withIdentifiers: [identifier])
        center.removeDeliveredNotifications(withIdentifiers: [identifier])
    }

    /// Cancels reminders for multiple entries (e.g. when deleting a pet).
    func cancelReminders(for entryIds: [UUID]) {
        let identifiers = entryIds.map { notificationIdentifier(for: $0) }
        guard !identifiers.isEmpty else { return }
        center.removePendingNotificationRequests(withIdentifiers: identifiers)
        center.removeDeliveredNotifications(withIdentifiers: identifiers)
    }

    /// Reconciles all pending local reminders with the current list of care entries.
    func syncAllReminders(entries: [CareEntry], notificationsEnabled: Bool) async {
        if !notificationsEnabled {
            center.removeAllPendingNotificationRequests()
            return
        }

        for entry in entries {
            await scheduleReminder(for: entry, notificationsEnabled: notificationsEnabled)
        }
    }

    /// Counts currently pending PetCare notifications for display in Profile or Dashboard.
    func pendingReminderCount() async -> Int {
        let requests = await center.pendingNotificationRequests()
        return requests.filter { $0.identifier.hasPrefix(AppConstants.Notifications.reminderPrefix) }.count
    }

    private func notificationIdentifier(for id: UUID) -> String {
        "\(AppConstants.Notifications.reminderPrefix)\(id.uuidString)"
    }
}
