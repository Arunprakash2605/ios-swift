import Foundation
import LocalAuthentication

/// Describes the biometric capability detected on the user's device.
enum BiometricCapability {
    case faceID
    case touchID
    case opticID
    case unavailable(String)

    var displayName: String {
        switch self {
        case .faceID: return "Face ID"
        case .touchID: return "Touch ID"
        case .opticID: return "Optic ID"
        case .unavailable: return "Biometrics"
        }
    }

    var systemImageName: String {
        switch self {
        case .faceID: return "faceid"
        case .touchID: return "touchid"
        case .opticID: return "opticid"
        case .unavailable: return "lock.shield"
        }
    }

    var isAvailable: Bool {
        if case .unavailable = self {
            return false
        }
        return true
    }

    var unavailableReason: String? {
        if case .unavailable(let reason) = self {
            return reason
        }
        return nil
    }
}

/// Errors mapped from Apple's `LocalAuthentication` framework.
enum BiometricAuthError: LocalizedError {
    case unavailable(String)
    case cancelled
    case fallbackRequested
    case failed(String)

    var errorDescription: String? {
        switch self {
        case .unavailable(let message):
            return message
        case .cancelled:
            return "Biometric authentication was cancelled."
        case .fallbackRequested:
            return "Please sign in with your email and password."
        case .failed(let message):
            return message
        }
    }
}

/// Wraps Apple's `LocalAuthentication` framework to check biometric availability and authenticate users.
final class BiometricService {
    /// Checks whether Face ID / Touch ID is available and enrolled on the current device.
    func checkAvailability() -> BiometricCapability {
        let context = LAContext()
        var authError: NSError?
        let canEvaluate = context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &authError)

        guard canEvaluate else {
            let reason = mapErrorMessage(from: authError)
            return .unavailable(reason)
        }

        switch context.biometryType {
        case .faceID:
            return .faceID
        case .touchID:
            return .touchID
        case .opticID:
            return .opticID
        case .none:
            return .unavailable("Biometric authentication is not available on this device.")
        @unknown default:
            return .unavailable("Biometric authentication is not supported on this device.")
        }
    }

    /// Evaluates biometric authentication via `LAContext`. Never fakes a successful result.
    func authenticate(reason: String = "Unlock your PetCare health records") async -> Result<Void, BiometricAuthError> {
        let context = LAContext()
        context.localizedFallbackTitle = "Use Email & Password"
        context.localizedCancelTitle = "Cancel"

        var policyError: NSError?
        guard context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &policyError) else {
            return .failure(.unavailable(mapErrorMessage(from: policyError)))
        }

        return await withCheckedContinuation { continuation in
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { success, error in
                if success {
                    continuation.resume(returning: .success(()))
                    return
                }

                if let laError = error as? LAError {
                    switch laError.code {
                    case .userCancel, .systemCancel, .appCancel:
                        continuation.resume(returning: .failure(.cancelled))
                    case .userFallback:
                        continuation.resume(returning: .failure(.fallbackRequested))
                    default:
                        continuation.resume(returning: .failure(.failed(self.mapLAError(laError))))
                    }
                } else {
                    let message = error?.localizedDescription ?? "Biometric authentication could not be verified."
                    continuation.resume(returning: .failure(.failed(message)))
                }
            }
        }
    }

    private func mapErrorMessage(from error: NSError?) -> String {
        guard let laError = error as? LAError else {
            return error?.localizedDescription ?? "Biometric authentication is unavailable on this device."
        }
        return mapLAError(laError)
    }

    private func mapLAError(_ error: LAError) -> String {
        switch error.code {
        case .biometryNotAvailable:
            return "Face ID or Touch ID is not available on this device."
        case .biometryNotEnrolled:
            return "No Face ID or Touch ID profile is enrolled. Enable it in iOS Settings or use manual login."
        case .biometryLockout:
            return "Biometrics locked due to too many failed attempts. Please unlock with your passcode or use manual login."
        case .passcodeNotSet:
            return "A device passcode is required to use biometric authentication."
        case .authenticationFailed:
            return "Biometric verification did not match. Please try again or use manual login."
        default:
            return error.localizedDescription
        }
    }
}
