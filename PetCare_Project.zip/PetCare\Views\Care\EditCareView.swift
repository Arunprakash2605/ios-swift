import SwiftUI

/// Modal form to modify an existing care or vaccination record.
struct EditCareView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss

    let entry: CareEntry

    @State private var viewModel: CareViewModel?

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                if let viewModel {
                    CareFormContent(viewModel: viewModel, includeStatusPicker: true)
                        .padding(AppConstants.Layout.screenPadding)
                }
            }
            .background(AppColors.background.ignoresSafeArea())
            .navigationTitle("Edit Care Entry")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                    .foregroundStyle(AppColors.textSecondary)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if viewModel?.updateCareEntry(entry) == true {
                            dismiss()
                        }
                    }
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(AppColors.primaryDark)
                }
            }
        }
        .onAppear {
            if viewModel == nil {
                let vm = CareViewModel(appState: appState)
                vm.loadForEditing(entry)
                viewModel = vm
            }
        }
    }
}
