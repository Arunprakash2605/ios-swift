import SwiftUI
import PhotosUI

/// Modal form for editing an existing pet's details.
struct EditPetView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss

    let pet: Pet

    @State private var viewModel: PetViewModel?
    @State private var selectedPhotoItem: PhotosPickerItem?

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                if let viewModel {
                    PetFormContent(
                        viewModel: viewModel,
                        selectedPhotoItem: $selectedPhotoItem
                    )
                    .padding(AppConstants.Layout.screenPadding)
                }
            }
            .background(AppColors.background.ignoresSafeArea())
            .navigationTitle("Edit \(pet.name)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                    .foregroundStyle(AppColors.textSecondary)
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if viewModel?.updatePet(pet) == true {
                            dismiss()
                        }
                    }
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(AppColors.primaryDark)
                }
            }
        }
        .onAppear {
            if viewModel == nil {
                let vm = PetViewModel(appState: appState)
                vm.loadForEditing(pet)
                viewModel = vm
            }
        }
        .onChange(of: selectedPhotoItem) { _, newItem in
            guard let newItem else { return }
            Task {
                if let data = try? await newItem.loadTransferable(type: Data.self) {
                    viewModel?.profileImageData = data
                }
            }
        }
    }
}
