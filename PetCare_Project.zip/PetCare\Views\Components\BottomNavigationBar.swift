import SwiftUI

/// Primary navigation sections displayed in the custom bottom navigation bar.
enum AppTab: Int, CaseIterable, Identifiable {
    case home
    case pets
    case care
    case profile

    var id: Int { rawValue }

    var title: String {
        switch self {
        case .home: return "Home"
        case .pets: return "My Pets"
        case .care: return "Care Records"
        case .profile: return "Profile"
        }
    }

    var icon: String {
        switch self {
        case .home: return "house"
        case .pets: return "pawprint"
        case .care: return "cross.case"
        case .profile: return "person"
        }
    }

    var selectedIcon: String {
        switch self {
        case .home: return "house.fill"
        case .pets: return "pawprint.fill"
        case .care: return "cross.case.fill"
        case .profile: return "person.fill"
        }
    }
}

/// Custom floating bottom navigation bar with four main sections.
struct BottomNavigationBar: View {
    @Binding var selectedTab: AppTab

    var body: some View {
        HStack(spacing: 6) {
            ForEach(AppTab.allCases) { tab in
                let isSelected = selectedTab == tab

                Button {
                    withAnimation(.spring(response: 0.28, dampingFraction: 0.82)) {
                        selectedTab = tab
                    }
                } label: {
                    VStack(spacing: 4) {
                        Image(systemName: isSelected ? tab.selectedIcon : tab.icon)
                            .font(.system(size: 19, weight: isSelected ? .semibold : .medium))
                            .symbolEffect(.bounce, value: isSelected)

                        Text(tab.title)
                            .font(.system(size: 11, weight: isSelected ? .semibold : .medium, design: .rounded))
                            .lineLimit(1)
                    }
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 9)
                    .foregroundStyle(isSelected ? AppColors.primaryDark : AppColors.textSecondary)
                    .background(
                        RoundedRectangle(cornerRadius: 16, style: .continuous)
                            .fill(isSelected ? AppColors.secondary.opacity(0.85) : Color.clear)
                    )
                }
                .buttonStyle(.plain)
                .accessibilityLabel(tab.title)
                .accessibilityAddTraits(isSelected ? .isSelected : [])
            }
        }
        .padding(.horizontal, 10)
        .padding(.vertical, 8)
        .background(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(AppColors.cardBackground)
                .shadow(color: Color.black.opacity(0.09), radius: 18, x: 0, y: 6)
        )
        .overlay(
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .stroke(AppColors.border, lineWidth: 1)
        )
        .padding(.horizontal, 16)
        .padding(.bottom, 8)
    }
}
