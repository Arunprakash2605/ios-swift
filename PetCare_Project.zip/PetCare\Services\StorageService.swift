import Foundation
import SwiftData

/// Errors surfaced during local SwiftData or UserDefaults persistence operations.
enum StorageError: LocalizedError {
    case initializationFailed(String)
    case fetchFailed(String)
    case saveFailed(String)
    case deleteFailed(String)
    case recordNotFound

    var errorDescription: String? {
        switch self {
        case .initializationFailed(let detail):
            return "Failed to initialize local storage: \(detail)"
        case .fetchFailed(let detail):
            return "Failed to load saved records: \(detail)"
        case .saveFailed(let detail):
            return "Unable to save changes: \(detail)"
        case .deleteFailed(let detail):
            return "Unable to delete record: \(detail)"
        case .recordNotFound:
            return "The selected record could not be found."
        }
    }
}

/// Centralized local persistence service powered by SwiftData and UserDefaults.
@MainActor
final class StorageService {
    let container: ModelContainer
    private let userDefaults: UserDefaults

    var context: ModelContext {
        container.mainContext
    }

    init(inMemory: Bool = false, userDefaults: UserDefaults = .standard) {
        self.userDefaults = userDefaults

        let schema = Schema([Pet.self, CareEntry.self])
        let configuration = ModelConfiguration(schema: schema, isStoredInMemoryOnly: inMemory)

        do {
            self.container = try ModelContainer(for: schema, configurations: [configuration])
        } catch {
            // Fallback to in-memory container if on-disk store is corrupted so the app never crashes at launch.
            do {
                let fallbackConfig = ModelConfiguration(schema: schema, isStoredInMemoryOnly: true)
                self.container = try ModelContainer(for: schema, configurations: [fallbackConfig])
            } catch {
                fatalError("Unrecoverable SwiftData container error: \(error.localizedDescription)")
            }
        }
    }

    // MARK: - Pet CRUD

    func fetchPets() throws -> [Pet] {
        do {
            let descriptor = FetchDescriptor<Pet>(sortBy: [SortDescriptor(\.createdAt, order: .reverse)])
            return try context.fetch(descriptor)
        } catch {
            throw StorageError.fetchFailed(error.localizedDescription)
        }
    }

    func addPet(_ pet: Pet) throws {
        context.insert(pet)
        try saveContext()
    }

    func updatePet() throws {
        try saveContext()
    }

    func deletePet(_ pet: Pet) throws {
        context.delete(pet)
        try saveContext()
    }

    // MARK: - Care Entry CRUD

    func fetchCareEntries() throws -> [CareEntry] {
        do {
            let descriptor = FetchDescriptor<CareEntry>(sortBy: [SortDescriptor(\.scheduledDate, order: .forward)])
            let entries = try context.fetch(descriptor)
            var didMutateStatus = false
            for entry in entries where entry.refreshAutomaticStatus() {
                didMutateStatus = true
            }
            if didMutateStatus {
                try saveContext()
            }
            return entries
        } catch let error as StorageError {
            throw error
        } catch {
            throw StorageError.fetchFailed(error.localizedDescription)
        }
    }

    func findCareEntry(id: UUID) -> CareEntry? {
        let descriptor = FetchDescriptor<CareEntry>(predicate: #Predicate { $0.id == id })
        return try? context.fetch(descriptor).first
    }

    func addCareEntry(_ entry: CareEntry) throws {
        entry.refreshAutomaticStatus()
        context.insert(entry)
        try saveContext()
    }

    func updateCareEntry(_ entry: CareEntry) throws {
        entry.refreshAutomaticStatus()
        try saveContext()
    }

    func deleteCareEntry(id: UUID) throws {
        guard let existing = findCareEntry(id: id) else {
            throw StorageError.recordNotFound
        }
        context.delete(existing)
        try saveContext()
    }

    func deleteCareEntry(_ entry: CareEntry) throws {
        context.delete(entry)
        try saveContext()
    }

    func saveContext() throws {
        do {
            try context.save()
        } catch {
            throw StorageError.saveFailed(error.localizedDescription)
        }
    }

    // MARK: - Initial Sample Data (First Launch Only)

    /// Seeds realistic sample pets and care entries once on initial launch.
    /// Users can freely edit or delete all seeded data and it will not reappear.
    func seedInitialDataIfNeeded() {
        guard !userDefaults.bool(forKey: AppConstants.StorageKeys.hasSeededInitialData) else {
            return
        }

        do {
            let existingPets = try fetchPets()
            guard existingPets.isEmpty else {
                userDefaults.set(true, forKey: AppConstants.StorageKeys.hasSeededInitialData)
                return
            }

            let milo = Pet(
                name: "Milo",
                petType: .dog,
                breed: "Golden Retriever",
                age: 3.0,
                gender: .male,
                weight: 28.5
            )
            let luna = Pet(
                name: "Luna",
                petType: .cat,
                breed: "British Shorthair",
                age: 2.0,
                gender: .female,
                weight: 4.3
            )
            let kiwi = Pet(
                name: "Kiwi",
                petType: .bird,
                breed: "Cockatiel",
                age: 1.5,
                gender: .female,
                weight: 0.1
            )

            context.insert(milo)
            context.insert(luna)
            context.insert(kiwi)

            let sampleEntries: [CareEntry] = [
                CareEntry(
                    title: "Rabies Booster Vaccine",
                    category: .vaccination,
                    scheduledDate: Date.offsetFromToday(days: 2, hour: 10, minute: 30),
                    vetClinicName: "GreenPaws Veterinary Clinic",
                    dosageDetails: "1 mL subcutaneous booster",
                    notes: "Bring vaccination booklet for annual stamp.",
                    pet: milo
                ),
                CareEntry(
                    title: "Annual Wellness Checkup",
                    category: .vetVisit,
                    scheduledDate: Date.offsetFromToday(days: 5, hour: 14, minute: 0),
                    vetClinicName: "Harbor Animal Hospital",
                    dosageDetails: "Full physical + dental exam",
                    notes: "Ask vet about joint supplement options.",
                    pet: luna
                ),
                CareEntry(
                    title: "FVRCP Core Vaccination",
                    category: .vaccination,
                    scheduledDate: Date.offsetFromToday(days: -2, hour: 11, minute: 0),
                    vetClinicName: "Harbor Animal Hospital",
                    dosageDetails: "1 dose FVRCP",
                    notes: "Reschedule as soon as possible.",
                    pet: luna
                ),
                CareEntry(
                    title: "Full Coat Grooming & Nail Trim",
                    category: .grooming,
                    scheduledDate: Date.offsetFromToday(days: -6, hour: 15, minute: 30),
                    vetClinicName: "Happy Tails Spa",
                    dosageDetails: "Hypoallergenic oat shampoo",
                    notes: "Completed smoothly with ear cleaning.",
                    status: .completed,
                    completedAt: Date.offsetFromToday(days: -6, hour: 16, minute: 30),
                    pet: milo
                ),
                CareEntry(
                    title: "Vitamin & Pellet Nutrition Plan",
                    category: .diet,
                    scheduledDate: Date.offsetFromToday(days: 1, hour: 9, minute: 0),
                    vetClinicName: "Avian Care Center",
                    dosageDetails: "2 tbsp fortified pellets daily",
                    notes: "Include fresh leafy greens in the morning.",
                    pet: kiwi
                )
            ]

            for entry in sampleEntries {
                entry.refreshAutomaticStatus()
                context.insert(entry)
            }

            try context.save()
            userDefaults.set(true, forKey: AppConstants.StorageKeys.hasSeededInitialData)
        } catch {
            // Leave flag unset if seeding fails so it can retry cleanly on next launch.
        }
    }

    // MARK: - User Account & Preferences Persistence

    func loadUser() -> User {
        guard
            let data = userDefaults.data(forKey: AppConstants.StorageKeys.userProfileData),
            let user = try? JSONDecoder().decode(User.self, from: data)
        else {
            let fallback = User.defaultUser
            saveUser(fallback)
            return fallback
        }
        return user
    }

    func saveUser(_ user: User) {
        if let data = try? JSONEncoder().encode(user) {
            userDefaults.set(data, forKey: AppConstants.StorageKeys.userProfileData)
        }
    }

    var isBiometricLoginEnabled: Bool {
        get {
            if userDefaults.object(forKey: AppConstants.StorageKeys.biometricEnabled) == nil {
                return true
            }
            return userDefaults.bool(forKey: AppConstants.StorageKeys.biometricEnabled)
        }
        set {
            userDefaults.set(newValue, forKey: AppConstants.StorageKeys.biometricEnabled)
        }
    }

    var areNotificationsEnabled: Bool {
        get {
            if userDefaults.object(forKey: AppConstants.StorageKeys.notificationsEnabled) == nil {
                return true
            }
            return userDefaults.bool(forKey: AppConstants.StorageKeys.notificationsEnabled)
        }
        set {
            userDefaults.set(newValue, forKey: AppConstants.StorageKeys.notificationsEnabled)
        }
    }
}
