import SwiftUI

/// Search bar and horizontal category/status filter chips integrated with `CareListView`.
struct SearchFilterView: View {
    @Bindable var viewModel: SearchViewModel

    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            // Search Input
            HStack(spacing: 10) {
                Image(systemName: "magnifyingglass")
                    .foregroundStyle(AppColors.textTertiary)

                TextField("Search by activity title or pet name...", text: $viewModel.searchQuery)
                    .font(.system(size: 15))
                    .foregroundStyle(AppColors.textPrimary)
                    .autocorrectionDisabled()

                if !viewModel.searchQuery.isEmpty {
                    Button {
                        viewModel.searchQuery = ""
                    } label: {
                        Image(systemName: "xmark.circle.fill")
                            .foregroundStyle(AppColors.textTertiary)
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("Clear search text")
                }
            }
            .padding(.horizontal, 14)
            .frame(height: 44)
            .background(AppColors.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 14, style: .continuous)
                    .stroke(AppColors.border, lineWidth: 1)
            )

            // Category Filter Chips
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 8) {
                    FilterChipButton(
                        title: "All",
                        icon: "square.grid.2x2",
                        isSelected: viewModel.selectedCategory == nil
                    ) {
                        viewModel.selectedCategory = nil
                    }

                    ForEach(CareCategory.allCases) { category in
                        FilterChipButton(
                            title: category.rawValue,
                            icon: category.iconName,
                            isSelected: viewModel.selectedCategory == category
                        ) {
                            viewModel.selectedCategory = category
                        }
                    }
                }
            }

            // Status Filter Chips + Clear Filter Action
            HStack(spacing: 8) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        FilterChipButton(
                            title: "All Status",
                            isSelected: viewModel.selectedStatus == nil,
                            selectedColor: AppColors.primaryDark
                        ) {
                            viewModel.selectedStatus = nil
                        }

                        ForEach(CareStatus.allCases) { status in
                            FilterChipButton(
                                title: status.rawValue,
                                icon: status.iconName,
                                isSelected: viewModel.selectedStatus == status,
                                selectedColor: status.foregroundColor
                            ) {
                                viewModel.selectedStatus = status
                            }
                        }
                    }
                }

                if viewModel.hasActiveFilters {
                    Button {
                        withAnimation(.easeInOut(duration: 0.2)) {
                            viewModel.clearFilters()
                        }
                    } label: {
                        Text("Clear Filter")
                            .font(.system(size: 12, weight: .semibold, design: .rounded))
                            .foregroundStyle(AppColors.statusOverdue)
                            .padding(.horizontal, 10)
                            .padding(.vertical, 7)
                            .background(AppColors.statusOverdueBackground)
                            .clipShape(Capsule())
                    }
                    .buttonStyle(.plain)
                }
            }
        }
    }
}

private struct FilterChipButton: View {
    let title: String
    var icon: String? = nil
    let isSelected: Bool
    var selectedColor: Color = AppColors.primary
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 5) {
                if let icon {
                    Image(systemName: icon)
                        .font(.system(size: 11, weight: .semibold))
                }
                Text(title)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
            }
            .foregroundStyle(isSelected ? .white : AppColors.textSecondary)
            .padding(.horizontal, 12)
            .padding(.vertical, 7)
            .background(isSelected ? selectedColor : AppColors.cardBackground)
            .clipShape(Capsule())
            .overlay(
                Capsule()
                    .stroke(isSelected ? selectedColor : AppColors.border, lineWidth: 1)
            )
        }
        .buttonStyle(.plain)
    }
}
