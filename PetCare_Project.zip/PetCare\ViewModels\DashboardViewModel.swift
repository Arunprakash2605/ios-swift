import Foundation
import Observation

/// Provides dynamic statistics, upcoming appointments, and recent activity feeds for the Dashboard.
@MainActor
@Observable
final class DashboardViewModel {
    private let appState: AppState

    init(appState: AppState) {
        self.appState = appState
    }

    var greetingName: String {
        let first = appState.currentUser.fullName
            .split(separator: " ")
            .first
            .map(String.init)
        return (first?.isEmpty == false) ? (first ?? "Friend") : "Friend"
    }

    var currentDateText: String {
        Date().formattedHeaderDate
    }

    var totalPetsCount: Int {
        appState.pets.count
    }

    var upcomingAppointmentsCount: Int {
        appState.careEntries.filter { $0.status == .scheduled }.count
    }

    var dueVaccinationsCount: Int {
        appState.careEntries.filter {
            $0.category == .vaccination && $0.status != .completed
        }.count
    }

    var completedActivitiesCount: Int {
        appState.careEntries.filter { $0.status == .completed }.count
    }

    /// Upcoming and overdue entries prioritized chronologically so urgent items appear first.
    var upcomingAppointments: [CareEntry] {
        appState.careEntries
            .filter { $0.status != .completed }
            .sorted { lhs, rhs in
                if lhs.status != rhs.status {
                    return lhs.status == .overdue
                }
                return lhs.scheduledDate < rhs.scheduledDate
            }
            .prefix(5)
            .map { $0 }
    }

    /// Most recently completed or updated activities for the Recent Care Activities section.
    var recentActivities: [CareEntry] {
        appState.careEntries
            .sorted { lhs, rhs in
                let lhsDate = lhs.completedAt ?? lhs.createdAt
                let rhsDate = rhs.completedAt ?? rhs.createdAt
                return lhsDate > rhsDate
            }
            .prefix(4)
            .map { $0 }
    }

    var overdueCount: Int {
        appState.careEntries.filter { $0.status == .overdue }.count
    }

    var pendingNotificationsCount: Int {
        appState.pendingNotificationCount
    }

    var hasPets: Bool {
        !appState.pets.isEmpty
    }

    func refresh() {
        appState.reloadAllData()
        Task {
            await appState.refreshNotificationState()
        }
    }

    func navigateToProfile() {
        appState.selectedTab = .profile
    }

    func navigateToAllRecords() {
        appState.selectedTab = .care
    }
}
