import SwiftUI
import UIKit
import UserNotifications

/// User profile, biometric & notification preferences, application details, and logout action.
struct ProfileView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.openURL) private var openURL

    @State private var biometricCapability: BiometricCapability = .unavailable("")
    @State private var showLogoutConfirmation = false
    @State private var showPermissionAlert = false

    private var userInitials: String {
        let components = appState.currentUser.fullName
            .split(separator: " ")
            .prefix(2)
            .compactMap { $0.first.map(String.init) }
        return components.isEmpty ? "PC" : components.joined().uppercased()
    }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 18) {
                    profileHeaderCard
                    securitySettingsCard
                    notificationSettingsCard
                    appInfoCard
                    logoutSection
                }
                .padding(.horizontal, AppConstants.Layout.screenPadding)
                .padding(.top, 10)
                .padding(.bottom, AppConstants.Layout.bottomBarClearance)
            }
            .background(AppColors.background.ignoresSafeArea())
            .navigationTitle("Profile")
            .navigationBarTitleDisplayMode(.large)
            .alert("Sign Out of PetCare?", isPresented: $showLogoutConfirmation) {
                Button("Cancel", role: .cancel) {}
                Button("Sign Out", role: .destructive) {
                    appState.signOut()
                }
            } message: {
                Text("You can sign back in anytime using \(biometricCapability.displayName) or your email and password.")
            }
            .alert("Notifications Disabled in iOS Settings", isPresented: $showPermissionAlert) {
                Button("Cancel", role: .cancel) {}
                Button("Open Settings") {
                    if let url = URL(string: UIApplication.openSettingsURLString) {
                        openURL(url)
                    }
                }
            } message: {
                Text("Please allow notifications for PetCare in iOS Settings to receive vaccination and appointment reminders.")
            }
        }
        .onAppear {
            biometricCapability = appState.biometricService.checkAvailability()
            Task {
                await appState.refreshNotificationState()
            }
        }
    }

    // MARK: - Profile Card

    private var profileHeaderCard: some View {
        VStack(spacing: 14) {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(
                            colors: [AppColors.primary, AppColors.primaryDark],
                            startPoint: .topLeading,
                            endPoint: .bottomTrailing
                        )
                    )
                    .frame(width: 86, height: 86)
                    .shadow(color: AppColors.primary.opacity(0.25), radius: 10, x: 0, y: 4)

                Text(userInitials)
                    .font(.system(size: 28, weight: .bold, design: .rounded))
                    .foregroundStyle(.white)
            }

            VStack(spacing: 4) {
                Text(appState.currentUser.fullName)
                    .font(.system(size: 21, weight: .bold, design: .rounded))
                    .foregroundStyle(AppColors.textPrimary)

                Text(appState.currentUser.email)
                    .font(.system(size: 14, weight: .medium))
                    .foregroundStyle(AppColors.textSecondary)

                Text("Member since \(appState.currentUser.memberSince.formattedMediumDate)")
                    .font(.system(size: 12))
                    .foregroundStyle(AppColors.textTertiary)
                    .padding(.top, 2)
            }
        }
        .frame(maxWidth: .infinity)
        .petCareCard(padding: 20)
    }

    // MARK: - Biometric Settings

    private var securitySettingsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("Security & Biometrics", systemImage: "lock.shield.fill")
                .font(.system(size: 15, weight: .bold, design: .rounded))
                .foregroundStyle(AppColors.textPrimary)

            Toggle(isOn: Binding(
                get: { appState.isBiometricEnabled },
                set: { appState.setBiometricEnabled($0) }
            )) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Use \(biometricCapability.displayName)")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(AppColors.textPrimary)

                    Text(
                        biometricCapability.unavailableReason ??
                        "Unlock PetCare quickly using \(biometricCapability.displayName)."
                    )
                    .font(.system(size: 12))
                    .foregroundStyle(AppColors.textSecondary)
                }
            }
            .tint(AppColors.primary)
            .disabled(!biometricCapability.isAvailable)
        }
        .petCareCard(padding: 16)
    }

    // MARK: - Notification Settings

    private var notificationSettingsCard: some View {
        VStack(alignment: .leading, spacing: 14) {
            Label("Reminders & Notifications", systemImage: "bell.badge.fill")
                .font(.system(size: 15, weight: .bold, design: .rounded))
                .foregroundStyle(AppColors.textPrimary)

            Toggle(isOn: Binding(
                get: { appState.notificationsEnabled },
                set: { newValue in
                    Task {
                        if newValue && appState.notificationAuthorizationStatus == .denied {
                            showPermissionAlert = true
                        } else {
                            await appState.setNotificationsEnabled(newValue)
                        }
                    }
                }
            )) {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Care & Vaccination Reminders")
                        .font(.system(size: 15, weight: .semibold))
                        .foregroundStyle(AppColors.textPrimary)

                    Text(notificationStatusSubtitle)
                        .font(.system(size: 12))
                        .foregroundStyle(AppColors.textSecondary)
                }
            }
            .tint(AppColors.primary)

            if appState.notificationAuthorizationStatus == .denied {
                Button("Open iOS Notification Settings") {
                    if let url = URL(string: UIApplication.openSettingsURLString) {
                        openURL(url)
                    }
                }
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(AppColors.primaryDark)
            }
        }
        .petCareCard(padding: 16)
    }

    private var notificationStatusSubtitle: String {
        switch appState.notificationAuthorizationStatus {
        case .authorized, .provisional, .ephemeral:
            return appState.notificationsEnabled
                ? "\(appState.pendingNotificationCount) upcoming reminder(s) scheduled."
                : "Reminders paused. Enable to schedule local notifications."
        case .denied:
            return "System notification permission is denied."
        case .notDetermined:
            return "Tap to allow local vaccination and visit reminders."
        @unknown default:
            return "Manage local appointment reminders."
        }
    }

    // MARK: - Application Information

    private var appInfoCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Application Information", systemImage: "info.circle.fill")
                .font(.system(size: 15, weight: .bold, design: .rounded))
                .foregroundStyle(AppColors.textPrimary)

            InfoRow(title: "Application", value: AppConstants.AppInfo.name)
            Divider().overlay(AppColors.border)
            InfoRow(title: "Description", value: AppConstants.AppInfo.subtitle)
            Divider().overlay(AppColors.border)
            InfoRow(title: "Version", value: "\(AppConstants.AppInfo.version) (\(AppConstants.AppInfo.build))")
            Divider().overlay(AppColors.border)
            InfoRow(title: "Local Storage", value: "SwiftData On-Device")
        }
        .petCareCard(padding: 16)
    }

    private var logoutSection: some View {
        CustomButton(title: "Log Out", icon: "rectangle.portrait.and.arrow.right", style: .destructive) {
            showLogoutConfirmation = true
        }
    }
}

private struct InfoRow: View {
    let title: String
    let value: String

    var body: some View {
        HStack {
            Text(title)
                .font(.system(size: 13, weight: .medium))
                .foregroundStyle(AppColors.textSecondary)
            Spacer()
            Text(value)
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(AppColors.textPrimary)
                .multilineTextAlignment(.trailing)
        }
    }
}
