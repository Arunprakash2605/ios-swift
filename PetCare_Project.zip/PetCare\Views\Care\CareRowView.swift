import SwiftUI

/// Card row displaying a single care or vaccination entry in lists.
struct CareRowView: View {
    let entry: CareEntry

    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .top, spacing: 12) {
                ZStack {
                    RoundedRectangle(cornerRadius: 13, style: .continuous)
                        .fill(entry.category.tintColor.opacity(0.14))
                        .frame(width: 44, height: 44)

                    Image(systemName: entry.category.iconName)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(entry.category.tintColor)
                }

                VStack(alignment: .leading, spacing: 4) {
                    HStack(alignment: .top, spacing: 8) {
                        Text(entry.title)
                            .font(.system(size: 16, weight: .bold, design: .rounded))
                            .foregroundStyle(AppColors.textPrimary)
                            .lineLimit(2)

                        Spacer(minLength: 4)

                        StatusBadge(status: entry.status, compact: true)
                    }

                    HStack(spacing: 8) {
                        Label(entry.petName, systemImage: "pawprint.fill")
                            .font(.system(size: 13, weight: .semibold))
                            .foregroundStyle(AppColors.primaryDark)

                        CategoryBadge(category: entry.category)
                    }
                }
            }

            Divider()
                .overlay(AppColors.border)

            HStack(spacing: 14) {
                Label(entry.scheduledDate.formattedDateAndTime, systemImage: "calendar")
                    .lineLimit(1)

                Spacer(minLength: 4)

                Label(entry.vetClinicName, systemImage: "building.2.fill")
                    .lineLimit(1)
            }
            .font(.system(size: 12, weight: .medium))
            .foregroundStyle(AppColors.textSecondary)
        }
        .petCareCard(padding: 14)
    }
}
