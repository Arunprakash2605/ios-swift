import SwiftUI

/// Displays all registered pets in card rows with quick search, add action, and detail navigation.
struct PetListView: View {
    @Environment(AppState.self) private var appState
    @State private var viewModel: PetViewModel?
    @State private var searchText: String = ""
    @State private var showAddPetSheet: Bool = false

    private var filteredPets: [Pet] {
        let allPets = viewModel?.pets ?? []
        let query = searchText.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !query.isEmpty else { return allPets }
        return allPets.filter {
            $0.name.localizedCaseInsensitiveContains(query) ||
            $0.breed.localizedCaseInsensitiveContains(query) ||
            $0.petType.rawValue.localizedCaseInsensitiveContains(query)
        }
    }

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 16) {
                    headerBar
                    searchBar

                    if filteredPets.isEmpty {
                        if (viewModel?.pets ?? []).isEmpty {
                            EmptyStateView(
                                icon: "pawprint.fill",
                                title: "No Pets Registered",
                                message: "Add your dog, cat, bird, or rabbit to track vaccinations and vet appointments.",
                                actionTitle: "Add New Pet"
                            ) {
                                showAddPetSheet = true
                            }
                        } else {
                            EmptyStateView(
                                icon: "magnifyingglass",
                                title: "No Matching Pets",
                                message: "Try searching by another pet name, breed, or species."
                            )
                        }
                    } else {
                        LazyVStack(spacing: 12) {
                            ForEach(filteredPets, id: \.id) { pet in
                                NavigationLink(value: pet.id) {
                                    PetCardRow(
                                        pet: pet,
                                        pendingCount: viewModel?.upcomingCount(for: pet) ?? 0
                                    )
                                }
                                .buttonStyle(.plain)
                            }
                        }
                    }
                }
                .padding(.horizontal, AppConstants.Layout.screenPadding)
                .padding(.top, 10)
                .padding(.bottom, AppConstants.Layout.bottomBarClearance)
            }
            .background(AppColors.background.ignoresSafeArea())
            .navigationBarHidden(true)
            .navigationDestination(for: UUID.self) { petId in
                PetDetailView(petId: petId)
            }
            .sheet(isPresented: $showAddPetSheet) {
                AddPetView()
            }
        }
        .onAppear {
            if viewModel == nil {
                viewModel = PetViewModel(appState: appState)
            }
        }
    }

    private var headerBar: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text("My Pets")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundStyle(AppColors.textPrimary)

                Text("\(appState.pets.count) registered \(appState.pets.count == 1 ? "companion" : "companions")")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(AppColors.textSecondary)
            }

            Spacer()

            Button {
                showAddPetSheet = true
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "plus")
                    Text("Add Pet")
                }
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white)
                .padding(.horizontal, 14)
                .padding(.vertical, 9)
                .background(AppColors.primary)
                .clipShape(Capsule())
                .shadow(color: AppColors.primary.opacity(0.25), radius: 6, x: 0, y: 3)
            }
            .buttonStyle(.plain)
        }
    }

    private var searchBar: some View {
        HStack(spacing: 10) {
            Image(systemName: "magnifyingglass")
                .foregroundStyle(AppColors.textTertiary)
            TextField("Search pets by name, breed, or type...", text: $searchText)
                .font(.system(size: 15))
                .foregroundStyle(AppColors.textPrimary)
            if !searchText.isEmpty {
                Button {
                    searchText = ""
                } label: {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundStyle(AppColors.textTertiary)
                }
                .buttonStyle(.plain)
            }
        }
        .padding(.horizontal, 14)
        .frame(height: 44)
        .background(AppColors.cardBackground)
        .clipShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .stroke(AppColors.border, lineWidth: 1)
        )
    }
}

private struct PetCardRow: View {
    let pet: Pet
    let pendingCount: Int

    var body: some View {
        HStack(spacing: 14) {
            PetThumbnailView(
                petType: pet.petType,
                imageData: pet.profileImageData,
                size: 64,
                cornerRadius: 16
            )

            VStack(alignment: .leading, spacing: 5) {
                HStack {
                    Text(pet.name)
                        .font(.system(size: 17, weight: .bold, design: .rounded))
                        .foregroundStyle(AppColors.textPrimary)

                    Spacer()

                    HStack(spacing: 4) {
                        Image(systemName: pet.petType.iconName)
                            .font(.system(size: 11))
                        Text(pet.petType.rawValue)
                            .font(.system(size: 11, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(AppColors.primaryDark)
                    .padding(.horizontal, 9)
                    .padding(.vertical, 4)
                    .background(AppColors.secondary)
                    .clipShape(Capsule())
                }

                Text(pet.breed)
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(AppColors.textSecondary)

                HStack(spacing: 10) {
                    Label(pet.formattedAge, systemImage: "birthday.cake")
                    Label(pet.formattedWeight, systemImage: "scalemass")
                    if pendingCount > 0 {
                        Label("\(pendingCount) due", systemImage: "bell.badge.fill")
                            .foregroundStyle(AppColors.primaryDark)
                    }
                }
                .font(.system(size: 12))
                .foregroundStyle(AppColors.textSecondary)
            }

            Image(systemName: "chevron.right")
                .font(.system(size: 13, weight: .semibold))
                .foregroundStyle(AppColors.textTertiary)
        }
        .petCareCard(padding: 14)
    }
}
