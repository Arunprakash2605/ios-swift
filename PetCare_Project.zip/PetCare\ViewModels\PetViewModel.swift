import Foundation
import Observation

/// Manages pet CRUD operations, form validation, and pet-level care lookups.
@MainActor
@Observable
final class PetViewModel {
    private let appState: AppState

    // Form Fields (used by AddPetView and EditPetView)
    var name: String = ""
    var petType: PetType = .dog
    var breed: String = ""
    var ageText: String = ""
    var gender: PetGender = .male
    var weightText: String = ""
    var profileImageData: Data?

    // Validation Errors
    var nameError: String?
    var breedError: String?
    var ageError: String?
    var weightError: String?
    var generalErrorMessage: String?

    init(appState: AppState) {
        self.appState = appState
    }

    var pets: [Pet] {
        appState.pets
    }

    func pet(withId id: UUID) -> Pet? {
        appState.pets.first { $0.id == id }
    }

    func careEntries(for pet: Pet) -> [CareEntry] {
        appState.careEntries
            .filter { $0.pet?.id == pet.id }
            .sorted { $0.scheduledDate < $1.scheduledDate }
    }

    func upcomingCount(for pet: Pet) -> Int {
        careEntries(for: pet).filter { $0.status != .completed }.count
    }

    /// Loads an existing pet's values into form fields before editing.
    func loadForEditing(_ pet: Pet) {
        name = pet.name
        petType = pet.petType
        breed = pet.breed
        ageText = pet.age.truncatingRemainder(dividingBy: 1) == 0
            ? "\(Int(pet.age))"
            : String(format: "%.1f", pet.age)
        gender = pet.gender
        weightText = pet.weight.truncatingRemainder(dividingBy: 1) == 0
            ? "\(Int(pet.weight))"
            : String(format: "%.1f", pet.weight)
        profileImageData = pet.profileImageData
        clearErrors()
    }

    func resetForm() {
        name = ""
        petType = .dog
        breed = ""
        ageText = ""
        gender = .male
        weightText = ""
        profileImageData = nil
        clearErrors()
    }

    /// Validates input fields and creates a new persistent `Pet`.
    @discardableResult
    func addPet() -> Bool {
        guard let validated = validateForm() else { return false }

        let newPet = Pet(
            name: validated.name,
            petType: petType,
            breed: validated.breed,
            age: validated.age,
            gender: gender,
            weight: validated.weight,
            profileImageData: profileImageData
        )

        do {
            try appState.storageService.addPet(newPet)
            appState.reloadAllData()
            resetForm()
            return true
        } catch {
            generalErrorMessage = error.localizedDescription
            return false
        }
    }

    /// Validates input fields and saves edits to an existing `Pet`.
    @discardableResult
    func updatePet(_ pet: Pet) -> Bool {
        guard let validated = validateForm() else { return false }

        pet.name = validated.name
        pet.petType = petType
        pet.breed = validated.breed
        pet.age = validated.age
        pet.gender = gender
        pet.weight = validated.weight
        pet.profileImageData = profileImageData

        do {
            try appState.storageService.updatePet()
            appState.reloadAllData()
            Task {
                await appState.syncAllNotifications()
            }
            return true
        } catch {
            generalErrorMessage = error.localizedDescription
            return false
        }
    }

    /// Deletes a pet and cancels any local reminders tied to its care records.
    @discardableResult
    func deletePet(_ pet: Pet) -> Bool {
        let entryIds = careEntries(for: pet).map(\.id)
        do {
            appState.notificationService.cancelReminders(for: entryIds)
            try appState.storageService.deletePet(pet)
            appState.reloadAllData()
            Task {
                await appState.refreshNotificationState()
            }
            return true
        } catch {
            generalErrorMessage = error.localizedDescription
            return false
        }
    }

    private func validateForm() -> (name: String, breed: String, age: Double, weight: Double)? {
        clearErrors()
        var isValid = true

        let trimmedName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedBreed = breed.trimmingCharacters(in: .whitespacesAndNewlines)

        if trimmedName.isEmpty {
            nameError = "Pet name is required."
            isValid = false
        }

        if trimmedBreed.isEmpty {
            breedError = "Breed is required (e.g. Golden Retriever, Mixed)."
            isValid = false
        }

        let normalizedAge = ageText.replacingOccurrences(of: ",", with: ".").trimmingCharacters(in: .whitespacesAndNewlines)
        guard let parsedAge = Double(normalizedAge), parsedAge > 0, parsedAge <= 50 else {
            ageError = "Enter a valid age between 0.1 and 50 years."
            isValid = false
            return nilOrValidateWeight(isValid: false)
        }

        let normalizedWeight = weightText.replacingOccurrences(of: ",", with: ".").trimmingCharacters(in: .whitespacesAndNewlines)
        guard let parsedWeight = Double(normalizedWeight), parsedWeight > 0, parsedWeight <= 250 else {
            weightError = "Enter a valid weight in kg (greater than 0)."
            return nil
        }

        guard isValid else { return nil }
        return (trimmedName, trimmedBreed, parsedAge, parsedWeight)
    }

    private func nilOrValidateWeight(isValid: Bool) -> (name: String, breed: String, age: Double, weight: Double)? {
        let normalizedWeight = weightText.replacingOccurrences(of: ",", with: ".").trimmingCharacters(in: .whitespacesAndNewlines)
        if Double(normalizedWeight) == nil || (Double(normalizedWeight) ?? 0) <= 0 {
            weightError = "Enter a valid weight in kg (greater than 0)."
        }
        return nil
    }

    private func clearErrors() {
        nameError = nil
        breedError = nil
        ageError = nil
        weightError = nil
        generalErrorMessage = nil
    }
}
