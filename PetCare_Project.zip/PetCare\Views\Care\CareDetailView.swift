import SwiftUI

/// Detailed view for inspecting, completing, editing, or deleting a care or vaccination entry.
struct CareDetailView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss

    let entryId: UUID

    @State private var viewModel: CareViewModel?
    @State private var showEditSheet = false
    @State private var showDeleteAlert = false

    private var entry: CareEntry? {
        viewModel?.entry(withId: entryId)
    }

    var body: some View {
        Group {
            if let entry, let viewModel {
                ScrollView(showsIndicators: false) {
                    VStack(spacing: 16) {
                        headerSummaryCard(entry: entry)
                        detailsSectionCard(entry: entry)

                        if !entry.notes.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                            notesCard(notes: entry.notes)
                        }

                        actionButtonsSection(entry: entry, viewModel: viewModel)
                    }
                    .padding(.horizontal, AppConstants.Layout.screenPadding)
                    .padding(.top, 12)
                    .padding(.bottom, AppConstants.Layout.bottomBarClearance)
                }
                .background(AppColors.background.ignoresSafeArea())
                .navigationTitle("Care Details")
                .navigationBarTitleDisplayMode(.inline)
                .sheet(isPresented: $showEditSheet) {
                    EditCareView(entry: entry)
                }
                .alert("Delete Care Entry?", isPresented: $showDeleteAlert) {
                    Button("Cancel", role: .cancel) {}
                    Button("Delete", role: .destructive) {
                        if viewModel.deleteCareEntry(id: entry.id) {
                            dismiss()
                        }
                    }
                } message: {
                    Text("This will permanently remove \"\(entry.title)\" and cancel any scheduled reminder.")
                }
            } else {
                EmptyStateView(
                    icon: "doc.questionmark",
                    title: "Record Unavailable",
                    message: "This care entry may have been removed."
                )
                .padding()
                .background(AppColors.background.ignoresSafeArea())
            }
        }
        .onAppear {
            if viewModel == nil {
                viewModel = CareViewModel(appState: appState)
            }
        }
    }

    private func headerSummaryCard(entry: CareEntry) -> some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(alignment: .top, spacing: 12) {
                PetThumbnailView(
                    petType: entry.pet?.petType ?? .other,
                    imageData: entry.pet?.profileImageData,
                    size: 62,
                    cornerRadius: 16
                )

                VStack(alignment: .leading, spacing: 6) {
                    Text(entry.title)
                        .font(.system(size: 20, weight: .bold, design: .rounded))
                        .foregroundStyle(AppColors.textPrimary)

                    HStack(spacing: 6) {
                        Text(entry.petName)
                            .font(.system(size: 14, weight: .semibold))
                            .foregroundStyle(AppColors.primaryDark)

                        if let petType = entry.pet?.petType {
                            Text("• \(petType.rawValue)")
                                .font(.system(size: 13))
                                .foregroundStyle(AppColors.textSecondary)
                        }
                    }
                }
            }

            HStack(spacing: 8) {
                CategoryBadge(category: entry.category)
                StatusBadge(status: entry.status)
                Spacer()
            }
        }
        .petCareCard(padding: 18)
    }

    private func detailsSectionCard(entry: CareEntry) -> some View {
        VStack(spacing: 14) {
            DetailRow(
                icon: "calendar",
                label: "Scheduled Date",
                value: entry.scheduledDate.formattedDateAndTime
            )

            Divider().overlay(AppColors.border)

            DetailRow(
                icon: "building.2.fill",
                label: "Vet Clinic / Provider",
                value: entry.vetClinicName
            )

            Divider().overlay(AppColors.border)

            DetailRow(
                icon: "pills.fill",
                label: "Dosage / Treatment Details",
                value: entry.dosageDetails.isEmpty ? "No dosage details specified" : entry.dosageDetails
            )

            if let completedAt = entry.completedAt, entry.status == .completed {
                Divider().overlay(AppColors.border)
                DetailRow(
                    icon: "checkmark.seal.fill",
                    label: "Completed On",
                    value: completedAt.formattedDateAndTime
                )
            }
        }
        .petCareCard(padding: 18)
    }

    private func notesCard(notes: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Label("Treatment Notes", systemImage: "note.text")
                .font(.system(size: 14, weight: .bold, design: .rounded))
                .foregroundStyle(AppColors.textPrimary)

            Text(notes)
                .font(.system(size: 14))
                .foregroundStyle(AppColors.textSecondary)
                .fixedSize(horizontal: false, vertical: true)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .petCareCard(padding: 18)
    }

    private func actionButtonsSection(entry: CareEntry, viewModel: CareViewModel) -> some View {
        VStack(spacing: 10) {
            if entry.status != .completed {
                CustomButton(title: "Mark as Completed", icon: "checkmark.circle.fill", style: .primary) {
                    viewModel.markAsCompleted(entry)
                }
            }

            CustomButton(title: "Edit Entry", icon: "pencil", style: .secondary) {
                showEditSheet = true
            }

            CustomButton(title: "Delete Entry", icon: "trash.fill", style: .destructive) {
                showDeleteAlert = true
            }
        }
        .padding(.top, 4)
    }
}

private struct DetailRow: View {
    let icon: String
    let label: String
    let value: String

    var body: some View {
        HStack(alignment: .top, spacing: 12) {
            Image(systemName: icon)
                .font(.system(size: 15, weight: .semibold))
                .foregroundStyle(AppColors.primary)
                .frame(width: 24)

            VStack(alignment: .leading, spacing: 3) {
                Text(label)
                    .font(.system(size: 12, weight: .medium))
                    .foregroundStyle(AppColors.textSecondary)

                Text(value)
                    .font(.system(size: 15, weight: .semibold, design: .rounded))
                    .foregroundStyle(AppColors.textPrimary)
            }

            Spacer()
        }
    }
}
