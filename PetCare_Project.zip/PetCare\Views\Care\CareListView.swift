import SwiftUI

/// Scrollable list of all pet care and vaccination entries with integrated search and multi-criteria filtering.
struct CareListView: View {
    @Environment(AppState.self) private var appState
    @State private var searchViewModel: SearchViewModel?
    @State private var careViewModel: CareViewModel?

    @State private var showAddCareSheet = false
    @State private var entryPendingDelete: CareEntry?
    @State private var showDeleteAlert = false

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(spacing: 14) {
                    headerBar

                    if let searchViewModel {
                        SearchFilterView(viewModel: searchViewModel)

                        let results = searchViewModel.filteredEntries
                        if results.isEmpty {
                            if appState.careEntries.isEmpty {
                                EmptyStateView(
                                    icon: "cross.case.fill",
                                    title: "No Care Records Yet",
                                    message: "Track vaccinations, vet checkups, grooming appointments, and daily diet plans.",
                                    actionTitle: "Add Care Entry"
                                ) {
                                    showAddCareSheet = true
                                }
                            } else {
                                EmptyStateView(
                                    icon: "line.3.horizontal.decrease.circle",
                                    title: "No Matching Records",
                                    message: "No care entries match your current search or filter criteria.",
                                    actionTitle: "Clear Filters"
                                ) {
                                    searchViewModel.clearFilters()
                                }
                            }
                        } else {
                            LazyVStack(spacing: 12) {
                                ForEach(results, id: \.id) { entry in
                                    NavigationLink(value: entry.id) {
                                        CareRowView(entry: entry)
                                    }
                                    .buttonStyle(.plain)
                                    .contextMenu {
                                        if entry.status != .completed {
                                            Button {
                                                careViewModel?.markAsCompleted(entry)
                                            } label: {
                                                Label("Mark as Completed", systemImage: "checkmark.circle")
                                            }
                                        }

                                        Button(role: .destructive) {
                                            entryPendingDelete = entry
                                            showDeleteAlert = true
                                        } label: {
                                            Label("Delete Entry", systemImage: "trash")
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                .padding(.horizontal, AppConstants.Layout.screenPadding)
                .padding(.top, 10)
                .padding(.bottom, AppConstants.Layout.bottomBarClearance)
            }
            .background(AppColors.background.ignoresSafeArea())
            .refreshable {
                careViewModel?.refreshAllData()
            }
            .navigationBarHidden(true)
            .navigationDestination(for: UUID.self) { entryId in
                CareDetailView(entryId: entryId)
            }
            .sheet(isPresented: $showAddCareSheet) {
                AddCareView()
            }
            .alert("Delete Care Entry?", isPresented: $showDeleteAlert) {
                Button("Cancel", role: .cancel) {
                    entryPendingDelete = nil
                }
                Button("Delete", role: .destructive) {
                    if let target = entryPendingDelete {
                        careViewModel?.deleteCareEntry(id: target.id)
                    }
                    entryPendingDelete = nil
                }
            } message: {
                Text("Are you sure you want to delete \"\(entryPendingDelete?.title ?? "this record")\"? Any scheduled reminder will also be cancelled.")
            }
        }
        .onAppear {
            if searchViewModel == nil {
                searchViewModel = SearchViewModel(appState: appState)
            }
            if careViewModel == nil {
                careViewModel = CareViewModel(appState: appState)
            }
            appState.refreshCareStatuses()
        }
    }

    private var headerBar: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text("Care Records")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundStyle(AppColors.textPrimary)

                Text("\(appState.careEntries.count) total \(appState.careEntries.count == 1 ? "entry" : "entries")")
                    .font(.system(size: 13, weight: .medium))
                    .foregroundStyle(AppColors.textSecondary)
            }

            Spacer()

            Button {
                showAddCareSheet = true
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "plus")
                    Text("Add Entry")
                }
                .font(.system(size: 14, weight: .semibold, design: .rounded))
                .foregroundStyle(.white)
                .padding(.horizontal, 14)
                .padding(.vertical, 9)
                .background(AppColors.primary)
                .clipShape(Capsule())
                .shadow(color: AppColors.primary.opacity(0.25), radius: 6, x: 0, y: 3)
            }
            .buttonStyle(.plain)
        }
    }
}
