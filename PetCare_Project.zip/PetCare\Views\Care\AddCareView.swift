import SwiftUI

/// Modal form to create and persist a new vaccination or care record.
struct AddCareView: View {
    @Environment(AppState.self) private var appState
    @Environment(\.dismiss) private var dismiss

    var preselectedPetId: UUID? = nil

    @State private var viewModel: CareViewModel?
    @State private var showAddPetSheet = false

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                if let viewModel {
                    if viewModel.availablePets.isEmpty {
                        EmptyStateView(
                            icon: "pawprint.fill",
                            title: "Register a Pet First",
                            message: "You need at least one pet profile before creating a vaccination or care entry.",
                            actionTitle: "Add New Pet"
                        ) {
                            showAddPetSheet = true
                        }
                        .padding(AppConstants.Layout.screenPadding)
                    } else {
                        CareFormContent(viewModel: viewModel, includeStatusPicker: false)
                            .padding(AppConstants.Layout.screenPadding)
                    }
                }
            }
            .background(AppColors.background.ignoresSafeArea())
            .navigationTitle("Add Care Entry")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                    .foregroundStyle(AppColors.textSecondary)
                }

                ToolbarItem(placement: .confirmationAction) {
                    Button("Save") {
                        if viewModel?.addCareEntry() == true {
                            dismiss()
                        }
                    }
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(AppColors.primaryDark)
                    .disabled(viewModel?.availablePets.isEmpty ?? true)
                }
            }
            .sheet(isPresented: $showAddPetSheet) {
                AddPetView()
            }
            .onChange(of: appState.pets.count) { _, _ in
                if viewModel?.selectedPetId == nil {
                    viewModel?.selectedPetId = appState.pets.first?.id
                }
            }
        }
        .onAppear {
            if viewModel == nil {
                viewModel = CareViewModel(appState: appState, preselectedPetId: preselectedPetId)
            }
        }
    }
}

/// Shared form body used by `AddCareView` and `EditCareView`.
struct CareFormContent: View {
    @Bindable var viewModel: CareViewModel
    let includeStatusPicker: Bool

    var body: some View {
        VStack(spacing: 16) {
            VStack(spacing: 16) {
                CustomTextField(
                    title: "Activity Title *",
                    placeholder: "e.g. Rabies Booster Vaccine",
                    text: $viewModel.title,
                    icon: "text.badge.checkmark",
                    autocapitalization: .words,
                    errorMessage: viewModel.titleError
                )

                // Pet Picker
                VStack(alignment: .leading, spacing: 6) {
                    Text("Select Pet *")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(AppColors.textSecondary)

                    Picker("Select Pet", selection: $viewModel.selectedPetId) {
                        Text("Choose a pet").tag(UUID?.none)
                        ForEach(viewModel.availablePets, id: \.id) { pet in
                            Text("\(pet.name) (\(pet.petType.rawValue))").tag(UUID?.some(pet.id))
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                    .frame(height: 46)
                    .background(AppColors.inputBackground)
                    .clipShape(RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous)
                            .stroke(viewModel.petError == nil ? AppColors.border : AppColors.error, lineWidth: 1)
                    )

                    if let petError = viewModel.petError {
                        Label(petError, systemImage: "exclamationmark.circle.fill")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(AppColors.error)
                    }
                }

                // Category Picker
                VStack(alignment: .leading, spacing: 6) {
                    Text("Category *")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(AppColors.textSecondary)

                    Picker("Category", selection: $viewModel.category) {
                        ForEach(CareCategory.allCases) { category in
                            Label(category.rawValue, systemImage: category.iconName).tag(category)
                        }
                    }
                    .pickerStyle(.menu)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                    .frame(height: 46)
                    .background(AppColors.inputBackground)
                    .clipShape(RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous)
                            .stroke(AppColors.border, lineWidth: 1)
                    )
                }

                // Date Picker
                VStack(alignment: .leading, spacing: 6) {
                    Text("Scheduled Date & Time *")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(AppColors.textSecondary)

                    DatePicker(
                        "Scheduled Date",
                        selection: $viewModel.scheduledDate,
                        displayedComponents: [.date, .hourAndMinute]
                    )
                    .datePickerStyle(.compact)
                    .labelsHidden()
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.horizontal, 12)
                    .frame(height: 46)
                    .background(AppColors.inputBackground)
                    .clipShape(RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous))
                    .overlay(
                        RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous)
                            .stroke(viewModel.dateError == nil ? AppColors.border : AppColors.error, lineWidth: 1)
                    )

                    if let dateError = viewModel.dateError {
                        Label(dateError, systemImage: "exclamationmark.circle.fill")
                            .font(.system(size: 12, weight: .medium))
                            .foregroundStyle(AppColors.error)
                    } else if viewModel.scheduledDate.isPastDay && viewModel.status != .completed {
                        Text("Dates before today are automatically tracked as Overdue unless marked Completed.")
                            .font(.system(size: 11))
                            .foregroundStyle(AppColors.textSecondary)
                    }
                }

                CustomTextField(
                    title: "Vet Clinic / Provider *",
                    placeholder: "e.g. GreenPaws Veterinary Clinic",
                    text: $viewModel.vetClinicName,
                    icon: "building.2.fill",
                    autocapitalization: .words,
                    errorMessage: viewModel.clinicError
                )

                CustomTextField(
                    title: "Dosage / Treatment Details",
                    placeholder: "e.g. 1 mL booster or annual exam",
                    text: $viewModel.dosageDetails,
                    icon: "pills.fill"
                )

                VStack(alignment: .leading, spacing: 6) {
                    Text("Additional Notes")
                        .font(.system(size: 13, weight: .semibold, design: .rounded))
                        .foregroundStyle(AppColors.textSecondary)

                    TextField("Add preparation notes or observations...", text: $viewModel.notes, axis: .vertical)
                        .lineLimit(3...5)
                        .font(.system(size: 15))
                        .foregroundStyle(AppColors.textPrimary)
                        .padding(12)
                        .background(AppColors.inputBackground)
                        .clipShape(RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous))
                        .overlay(
                            RoundedRectangle(cornerRadius: AppConstants.Layout.inputCornerRadius, style: .continuous)
                                .stroke(AppColors.border, lineWidth: 1)
                        )
                }

                if includeStatusPicker {
                    VStack(alignment: .leading, spacing: 6) {
                        Text("Care Status")
                            .font(.system(size: 13, weight: .semibold, design: .rounded))
                            .foregroundStyle(AppColors.textSecondary)

                        Picker("Care Status", selection: $viewModel.status) {
                            ForEach(CareStatus.allCases) { option in
                                Text(option.rawValue).tag(option)
                            }
                        }
                        .pickerStyle(.segmented)
                    }
                }

                if let generalError = viewModel.generalErrorMessage {
                    Text(generalError)
                        .font(.system(size: 13, weight: .medium))
                        .foregroundStyle(AppColors.error)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
            }
            .petCareCard(padding: 18)
        }
    }
}
