import SwiftUI

/// Main home dashboard displaying summary metrics, upcoming appointments, quick actions, and recent care activities.
struct DashboardView: View {
    @Environment(AppState.self) private var appState
    @State private var viewModel: DashboardViewModel?

    @State private var showAddPetSheet = false
    @State private var showAddCareSheet = false
    @State private var showNotificationSummary = false

    private let gridColumns = [
        GridItem(.flexible(), spacing: 12),
        GridItem(.flexible(), spacing: 12)
    ]

    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                if let viewModel {
                    VStack(spacing: AppConstants.Layout.sectionSpacing) {
                        headerSection(viewModel: viewModel)

                        if viewModel.overdueCount > 0 {
                            overdueBanner(count: viewModel.overdueCount)
                        }

                        statisticsGrid(viewModel: viewModel)
                        quickActionsSection(viewModel: viewModel)
                        upcomingAppointmentsSection(viewModel: viewModel)
                        recentActivitiesSection(viewModel: viewModel)
                    }
                    .padding(.horizontal, AppConstants.Layout.screenPadding)
                    .padding(.top, 10)
                    .padding(.bottom, AppConstants.Layout.bottomBarClearance)
                }
            }
            .background(AppColors.background.ignoresSafeArea())
            .refreshable {
                viewModel?.refresh()
            }
            .navigationBarHidden(true)
            .navigationDestination(for: UUID.self) { entryId in
                CareDetailView(entryId: entryId)
            }
            .sheet(isPresented: $showAddPetSheet) {
                AddPetView()
            }
            .sheet(isPresented: $showAddCareSheet) {
                AddCareView()
            }
            .alert("Scheduled Reminders", isPresented: $showNotificationSummary) {
                Button("OK", role: .cancel) {}
            } message: {
                if appState.notificationsEnabled {
                    Text("You have \(appState.pendingNotificationCount) upcoming local reminder(s) scheduled.")
                } else {
                    Text("Local care reminders are currently turned off. Enable them in Profile settings.")
                }
            }
        }
        .onAppear {
            if viewModel == nil {
                viewModel = DashboardViewModel(appState: appState)
            } else {
                viewModel?.refresh()
            }
        }
    }

    // MARK: - Header

    private func headerSection(viewModel: DashboardViewModel) -> some View {
        HStack(spacing: 12) {
            VStack(alignment: .leading, spacing: 4) {
                Text(viewModel.currentDateText)
                    .font(.system(size: 13, weight: .medium, design: .rounded))
                    .foregroundStyle(AppColors.primaryDark)

                Text("Hello, \(viewModel.greetingName)")
                    .font(.system(size: 26, weight: .bold, design: .rounded))
                    .foregroundStyle(AppColors.textPrimary)
            }

            Spacer()

            Button {
                showNotificationSummary = true
            } label: {
                ZStack(alignment: .topTrailing) {
                    Circle()
                        .fill(AppColors.cardBackground)
                        .frame(width: 44, height: 44)
                        .overlay(
                            Circle().stroke(AppColors.border, lineWidth: 1)
                        )
                        .shadow(color: AppColors.shadow, radius: 6, x: 0, y: 2)
                        .overlay {
                            Image(systemName: "bell.fill")
                                .font(.system(size: 17, weight: .medium))
                                .foregroundStyle(AppColors.textPrimary)
                        }

                    if viewModel.pendingNotificationsCount > 0 {
                        Circle()
                            .fill(AppColors.primary)
                            .frame(width: 10, height: 10)
                            .offset(x: -2, y: 2)
                    }
                }
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Notifications")

            Button {
                viewModel.navigateToProfile()
            } label: {
                Circle()
                    .fill(AppColors.secondary)
                    .frame(width: 44, height: 44)
                    .overlay(
                        Circle().stroke(AppColors.primary.opacity(0.35), lineWidth: 1.5)
                    )
                    .overlay {
                        Image(systemName: "person.fill")
                            .font(.system(size: 18, weight: .semibold))
                            .foregroundStyle(AppColors.primaryDark)
                    }
            }
            .buttonStyle(.plain)
            .accessibilityLabel("Profile")
        }
    }

    private func overdueBanner(count: Int) -> some View {
        HStack(spacing: 12) {
            Image(systemName: "exclamationmark.triangle.fill")
                .font(.system(size: 18))
                .foregroundStyle(AppColors.statusOverdue)

            VStack(alignment: .leading, spacing: 2) {
                Text("\(count) Overdue Care \(count == 1 ? "Item" : "Items")")
                    .font(.system(size: 14, weight: .bold, design: .rounded))
                    .foregroundStyle(AppColors.statusOverdue)
                Text("Review overdue vaccinations or appointments in Care Records.")
                    .font(.system(size: 12))
                    .foregroundStyle(AppColors.textSecondary)
            }

            Spacer()
        }
        .padding(14)
        .background(AppColors.statusOverdueBackground)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .stroke(AppColors.statusOverdue.opacity(0.25), lineWidth: 1)
        )
    }

    // MARK: - Statistics Grid

    private func statisticsGrid(viewModel: DashboardViewModel) -> some View {
        LazyVGrid(columns: gridColumns, spacing: 12) {
            DashboardCard(
                title: "Total Pets",
                value: viewModel.totalPetsCount,
                icon: "pawprint.fill",
                tintColor: AppColors.primary,
                subtitle: "Registered profiles"
            )
            DashboardCard(
                title: "Upcoming",
                value: viewModel.upcomingAppointmentsCount,
                icon: "calendar.badge.clock",
                tintColor: AppColors.statusScheduled,
                subtitle: "Scheduled visits"
            )
            DashboardCard(
                title: "Due Vaccines",
                value: viewModel.dueVaccinationsCount,
                icon: "syringe.fill",
                tintColor: AppColors.warning,
                subtitle: "Pending doses"
            )
            DashboardCard(
                title: "Completed Care",
                value: viewModel.completedActivitiesCount,
                icon: "checkmark.seal.fill",
                tintColor: AppColors.statusCompleted,
                subtitle: "Finished activities"
            )
        }
    }

    // MARK: - Quick Actions

    private func quickActionsSection(viewModel: DashboardViewModel) -> some View {
        VStack(alignment: .leading, spacing: 10) {
            Text("Quick Actions")
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .foregroundStyle(AppColors.textPrimary)

            HStack(spacing: 10) {
                QuickActionPill(
                    title: "Add Pet",
                    icon: "plus.circle.fill",
                    tint: AppColors.primary
                ) {
                    showAddPetSheet = true
                }

                QuickActionPill(
                    title: "Add Care",
                    icon: "syringe.fill",
                    tint: AppColors.vetVisitTint
                ) {
                    showAddCareSheet = true
                }

                QuickActionPill(
                    title: "All Records",
                    icon: "list.bullet.rectangle.fill",
                    tint: AppColors.primaryDark
                ) {
                    viewModel.navigateToAllRecords()
                }
            }
        }
    }

    // MARK: - Upcoming Appointments

    private func upcomingAppointmentsSection(viewModel: DashboardViewModel) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Upcoming Appointments")
                    .font(.system(size: 18, weight: .bold, design: .rounded))
                    .foregroundStyle(AppColors.textPrimary)

                Spacer()

                Button("View All") {
                    viewModel.navigateToAllRecords()
                }
                .font(.system(size: 13, weight: .semibold, design: .rounded))
                .foregroundStyle(AppColors.primaryDark)
            }

            if viewModel.upcomingAppointments.isEmpty {
                EmptyStateView(
                    icon: "calendar.badge.checkmark",
                    title: "No Upcoming Appointments",
                    message: "You're all caught up! Schedule a vaccination, vet visit, or grooming session.",
                    actionTitle: viewModel.hasPets ? "Add Care Entry" : "Add Your First Pet"
                ) {
                    if viewModel.hasPets {
                        showAddCareSheet = true
                    } else {
                        showAddPetSheet = true
                    }
                }
            } else {
                VStack(spacing: 10) {
                    ForEach(viewModel.upcomingAppointments, id: \.id) { entry in
                        NavigationLink(value: entry.id) {
                            UpcomingAppointmentView(entry: entry)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }

    // MARK: - Recent Care Activities

    private func recentActivitiesSection(viewModel: DashboardViewModel) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Recent Care Activities")
                .font(.system(size: 18, weight: .bold, design: .rounded))
                .foregroundStyle(AppColors.textPrimary)

            if viewModel.recentActivities.isEmpty {
                EmptyStateView(
                    icon: "heart.text.square",
                    title: "No Care Activities Yet",
                    message: "Add a pet and record vaccinations, checkups, grooming, or diet plans."
                )
            } else {
                VStack(spacing: 10) {
                    ForEach(viewModel.recentActivities, id: \.id) { entry in
                        NavigationLink(value: entry.id) {
                            HStack(spacing: 12) {
                                ZStack {
                                    RoundedRectangle(cornerRadius: 12, style: .continuous)
                                        .fill(entry.category.tintColor.opacity(0.14))
                                        .frame(width: 42, height: 42)
                                    Image(systemName: entry.category.iconName)
                                        .font(.system(size: 17, weight: .semibold))
                                        .foregroundStyle(entry.category.tintColor)
                                }

                                VStack(alignment: .leading, spacing: 3) {
                                    Text(entry.title)
                                        .font(.system(size: 14, weight: .semibold, design: .rounded))
                                        .foregroundStyle(AppColors.textPrimary)
                                        .lineLimit(1)

                                    Text("\(entry.petName) • \(entry.scheduledDate.formattedMediumDate)")
                                        .font(.system(size: 12))
                                        .foregroundStyle(AppColors.textSecondary)
                                }

                                Spacer()

                                StatusBadge(status: entry.status, compact: true)
                            }
                            .petCareCard(padding: 13)
                        }
                        .buttonStyle(.plain)
                    }
                }
            }
        }
    }
}

private struct QuickActionPill: View {
    let title: String
    let icon: String
    let tint: Color
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 7) {
                Image(systemName: icon)
                    .font(.system(size: 19, weight: .semibold))
                    .foregroundStyle(tint)

                Text(title)
                    .font(.system(size: 12, weight: .semibold, design: .rounded))
                    .foregroundStyle(AppColors.textPrimary)
                    .lineLimit(1)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 13)
            .background(AppColors.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(AppColors.border, lineWidth: 1)
            )
            .shadow(color: AppColors.shadow, radius: 6, x: 0, y: 2)
        }
        .buttonStyle(.plain)
    }
}
