import Foundation
import CryptoKit

/// Local user account profile persisted via `StorageService`.
struct User: Codable, Equatable, Identifiable {
    let id: UUID
    var fullName: String
    var email: String
    var passwordHash: String
    var memberSince: Date

    init(
        id: UUID = UUID(),
        fullName: String,
        email: String,
        passwordHash: String,
        memberSince: Date = Date()
    ) {
        self.id = id
        self.fullName = fullName
        self.email = email
        self.passwordHash = passwordHash
        self.memberSince = memberSince
    }

    /// Creates a deterministic SHA-256 hex digest for storing local credentials without plaintext.
    static func hashPassword(_ password: String) -> String {
        let data = Data(password.utf8)
        let digest = SHA256.hash(data: data)
        return digest.map { String(format: "%02x", $0) }.joined()
    }

    /// Default initial account so a first-time user can sign in immediately or register their own account.
    static var defaultUser: User {
        User(
            fullName: AppConstants.DefaultAccount.name,
            email: AppConstants.DefaultAccount.email,
            passwordHash: hashPassword(AppConstants.DefaultAccount.password)
        )
    }
}
