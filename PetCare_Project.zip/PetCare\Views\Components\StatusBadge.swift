import SwiftUI

/// Visual status pill for `CareStatus` (Scheduled = Blue, Completed = Green, Overdue = Red).
struct StatusBadge: View {
    let status: CareStatus
    var compact: Bool = false

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: status.iconName)
                .font(.system(size: compact ? 10 : 11, weight: .semibold))
            Text(status.rawValue)
                .font(.system(size: compact ? 11 : 12, weight: .semibold, design: .rounded))
        }
        .foregroundStyle(status.foregroundColor)
        .padding(.horizontal, compact ? 8 : 10)
        .padding(.vertical, compact ? 4 : 5)
        .background(status.backgroundColor)
        .clipShape(Capsule())
    }
}

/// Visual category pill for `CareCategory`.
struct CategoryBadge: View {
    let category: CareCategory

    var body: some View {
        HStack(spacing: 4) {
            Image(systemName: category.iconName)
                .font(.system(size: 11, weight: .semibold))
            Text(category.rawValue)
                .font(.system(size: 12, weight: .medium, design: .rounded))
        }
        .foregroundStyle(category.tintColor)
        .padding(.horizontal, 10)
        .padding(.vertical, 5)
        .background(category.tintColor.opacity(0.12))
        .clipShape(Capsule())
    }
}
