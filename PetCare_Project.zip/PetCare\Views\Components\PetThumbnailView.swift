import SwiftUI
import UIKit

/// Renders either a user-selected pet photo or the lightweight PetCare asset thumbnail for the pet's type.
struct PetThumbnailView: View {
    let petType: PetType
    var imageData: Data? = nil
    var size: CGFloat = 52
    var cornerRadius: CGFloat = 14

    var body: some View {
        Group {
            if let imageData, let uiImage = UIImage(data: imageData) {
                Image(uiImage: uiImage)
                    .resizable()
                    .scaledToFill()
            } else {
                Image(petType.assetImageName)
                    .resizable()
                    .scaledToFill()
            }
        }
        .frame(width: size, height: size)
        .background(AppColors.mintSurface)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .overlay(
            RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                .stroke(AppColors.border.opacity(0.8), lineWidth: 1)
        )
    }
}
