import SwiftUI
import SwiftData

/// Application entry point configuring SwiftData persistence, shared `AppState`, and root routing.
@main
struct PetCareApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @State private var appState = AppState()

    var body: some Scene {
        WindowGroup {
            Group {
                if appState.isAuthenticated {
                    MainTabView()
                        .transition(.opacity)
                } else {
                    LoginView()
                        .transition(.opacity)
                }
            }
            .animation(.easeInOut(duration: 0.25), value: appState.isAuthenticated)
            .environment(appState)
            .modelContainer(appState.storageService.container)
            .tint(AppColors.primary)
            .preferredColorScheme(.light)
        }
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .active {
                appState.refreshCareStatuses()
                Task {
                    await appState.refreshNotificationState()
                }
            }
        }
    }
}
