import Foundation
import Observation

/// Manages care & vaccination entry creation, updates, completion, deletion, and validation.
@MainActor
@Observable
final class CareViewModel {
    private let appState: AppState

    // Form Fields
    var title: String = ""
    var selectedPetId: UUID?
    var category: CareCategory = .vaccination
    var scheduledDate: Date = Date.offsetFromToday(days: 1, hour: 10, minute: 0)
    var vetClinicName: String = ""
    var dosageDetails: String = ""
    var notes: String = ""
    var status: CareStatus = .scheduled

    // Validation Errors
    var titleError: String?
    var petError: String?
    var clinicError: String?
    var dateError: String?
    var generalErrorMessage: String?

    init(appState: AppState, preselectedPetId: UUID? = nil) {
        self.appState = appState
        self.selectedPetId = preselectedPetId ?? appState.pets.first?.id
    }

    var availablePets: [Pet] {
        appState.pets
    }

    var careEntries: [CareEntry] {
        appState.careEntries
    }

    func entry(withId id: UUID) -> CareEntry? {
        appState.careEntries.first { $0.id == id }
    }

    /// Loads an existing entry into form fields for editing.
    func loadForEditing(_ entry: CareEntry) {
        title = entry.title
        selectedPetId = entry.pet?.id ?? appState.pets.first?.id
        category = entry.category
        scheduledDate = entry.scheduledDate
        vetClinicName = entry.vetClinicName
        dosageDetails = entry.dosageDetails
        notes = entry.notes
        status = entry.status
        clearErrors()
    }

    /// Validates input fields and creates a new persistent `CareEntry`, scheduling a reminder if applicable.
    @discardableResult
    func addCareEntry() -> Bool {
        guard let validated = validateForm() else { return false }

        let newEntry = CareEntry(
            title: validated.title,
            category: category,
            scheduledDate: scheduledDate,
            vetClinicName: validated.clinic,
            dosageDetails: dosageDetails.trimmingCharacters(in: .whitespacesAndNewlines),
            notes: notes.trimmingCharacters(in: .whitespacesAndNewlines),
            pet: validated.pet
        )

        do {
            try appState.storageService.addCareEntry(newEntry)
            appState.reloadAllData()
            Task {
                await appState.notificationService.scheduleReminder(
                    for: newEntry,
                    notificationsEnabled: appState.notificationsEnabled
                )
                await appState.refreshNotificationState()
            }
            return true
        } catch {
            generalErrorMessage = error.localizedDescription
            return false
        }
    }

    /// Validates and saves edits to an existing `CareEntry`.
    @discardableResult
    func updateCareEntry(_ entry: CareEntry) -> Bool {
        guard let validated = validateForm() else { return false }

        entry.title = validated.title
        entry.pet = validated.pet
        entry.category = category
        entry.scheduledDate = scheduledDate
        entry.vetClinicName = validated.clinic
        entry.dosageDetails = dosageDetails.trimmingCharacters(in: .whitespacesAndNewlines)
        entry.notes = notes.trimmingCharacters(in: .whitespacesAndNewlines)
        entry.status = status
        if status == .completed && entry.completedAt == nil {
            entry.completedAt = Date()
        }

        do {
            try appState.storageService.updateCareEntry(entry)
            appState.reloadAllData()
            Task {
                await appState.notificationService.scheduleReminder(
                    for: entry,
                    notificationsEnabled: appState.notificationsEnabled
                )
                await appState.refreshNotificationState()
            }
            return true
        } catch {
            generalErrorMessage = error.localizedDescription
            return false
        }
    }

    /// Manually marks an entry as Completed so automatic status tracking preserves it.
    @discardableResult
    func markAsCompleted(_ entry: CareEntry) -> Bool {
        entry.status = .completed
        entry.completedAt = Date()

        do {
            try appState.storageService.updateCareEntry(entry)
            appState.notificationService.cancelReminder(for: entry.id)
            appState.reloadAllData()
            Task {
                await appState.refreshNotificationState()
            }
            return true
        } catch {
            generalErrorMessage = error.localizedDescription
            return false
        }
    }

    /// Deletes an entry safely by ID and cancels any pending local notification.
    @discardableResult
    func deleteCareEntry(id: UUID) -> Bool {
        do {
            appState.notificationService.cancelReminder(for: id)
            try appState.storageService.deleteCareEntry(id: id)
            appState.reloadAllData()
            Task {
                await appState.refreshNotificationState()
            }
            return true
        } catch {
            generalErrorMessage = error.localizedDescription
            return false
        }
    }

    func refreshAllData() {
        appState.reloadAllData()
    }

    private func validateForm() -> (title: String, pet: Pet, clinic: String)? {
        clearErrors()
        var isValid = true

        let trimmedTitle = title.trimmingCharacters(in: .whitespacesAndNewlines)
        let trimmedClinic = vetClinicName.trimmingCharacters(in: .whitespacesAndNewlines)

        if trimmedTitle.isEmpty {
            titleError = "Activity title is required."
            isValid = false
        }

        let matchedPet = selectedPetId.flatMap { id in
            appState.pets.first { $0.id == id }
        }
        if matchedPet == nil {
            petError = "Please select a pet for this care record."
            isValid = false
        }

        if trimmedClinic.isEmpty {
            clinicError = "Vet clinic or provider name is required."
            isValid = false
        }

        // Guard against wildly unrealistic dates (e.g., more than 25 years in the past or future).
        let yearsDifference = abs(scheduledDate.timeIntervalSinceNow) / (365 * 24 * 60 * 60)
        if yearsDifference > 25 {
            dateError = "Please choose a valid date within 25 years of today."
            isValid = false
        }

        guard isValid, let pet = matchedPet else {
            return nil
        }

        return (trimmedTitle, pet, trimmedClinic)
    }

    private func clearErrors() {
        titleError = nil
        petError = nil
        clinicError = nil
        dateError = nil
        generalErrorMessage = nil
    }
}
