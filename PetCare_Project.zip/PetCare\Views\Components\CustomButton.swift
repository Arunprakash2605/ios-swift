import SwiftUI

/// Visual style variants for `CustomButton`.
enum CustomButtonStyle {
    case primary
    case secondary
    case outline
    case destructive
}

/// Reusable rounded action button with loading state and consistent PetCare styling.
struct CustomButton: View {
    let title: String
    var icon: String? = nil
    var style: CustomButtonStyle = .primary
    var isLoading: Bool = false
    var isDisabled: Bool = false
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            HStack(spacing: 8) {
                if isLoading {
                    ProgressView()
                        .tint(foregroundColor)
                } else if let icon {
                    Image(systemName: icon)
                        .font(.system(size: 16, weight: .semibold))
                }

                Text(title)
                    .font(.system(size: 16, weight: .semibold, design: .rounded))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 50)
            .foregroundStyle(foregroundColor)
            .background(backgroundView)
            .clipShape(RoundedRectangle(cornerRadius: AppConstants.Layout.buttonCornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: AppConstants.Layout.buttonCornerRadius, style: .continuous)
                    .stroke(borderColor, lineWidth: style == .outline ? 1.5 : 0)
            )
            .shadow(
                color: style == .primary && !isDisabled ? AppColors.primary.opacity(0.25) : .clear,
                radius: 8,
                x: 0,
                y: 4
            )
            .opacity(isDisabled ? 0.55 : 1.0)
        }
        .buttonStyle(.plain)
        .disabled(isDisabled || isLoading)
    }

    private var foregroundColor: Color {
        switch style {
        case .primary:
            return .white
        case .secondary:
            return AppColors.primaryDark
        case .outline:
            return AppColors.primaryDark
        case .destructive:
            return AppColors.statusOverdue
        }
    }

    @ViewBuilder
    private var backgroundView: some View {
        switch style {
        case .primary:
            LinearGradient(
                colors: [AppColors.primary, AppColors.primaryDark],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
        case .secondary:
            AppColors.secondary
        case .outline:
            AppColors.cardBackground
        case .destructive:
            AppColors.statusOverdueBackground
        }
    }

    private var borderColor: Color {
        style == .outline ? AppColors.primary.opacity(0.45) : .clear
    }
}
