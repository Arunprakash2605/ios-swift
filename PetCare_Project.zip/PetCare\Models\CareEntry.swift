import Foundation
import SwiftData

/// Persistent SwiftData model representing a vaccination, vet visit, grooming, or diet care entry.
@Model
final class CareEntry {
    @Attribute(.unique) var id: UUID
    var title: String
    var categoryRaw: String
    var scheduledDate: Date
    var vetClinicName: String
    var dosageDetails: String
    var notes: String
    var statusRaw: String
    var completedAt: Date?
    var createdAt: Date

    var pet: Pet?

    init(
        id: UUID = UUID(),
        title: String,
        category: CareCategory,
        scheduledDate: Date,
        vetClinicName: String,
        dosageDetails: String = "",
        notes: String = "",
        status: CareStatus? = nil,
        completedAt: Date? = nil,
        createdAt: Date = Date(),
        pet: Pet? = nil
    ) {
        self.id = id
        self.title = title
        self.categoryRaw = category.rawValue
        self.scheduledDate = scheduledDate
        self.vetClinicName = vetClinicName
        self.dosageDetails = dosageDetails
        self.notes = notes
        let initialStatus = status ?? (scheduledDate.isTodayOrFuture ? .scheduled : .overdue)
        self.statusRaw = initialStatus.rawValue
        self.completedAt = initialStatus == .completed ? (completedAt ?? Date()) : nil
        self.createdAt = createdAt
        self.pet = pet
    }

    var category: CareCategory {
        get { CareCategory(rawValue: categoryRaw) ?? .vetVisit }
        set { categoryRaw = newValue.rawValue }
    }

    var status: CareStatus {
        get { CareStatus(rawValue: statusRaw) ?? .scheduled }
        set {
            statusRaw = newValue.rawValue
            if newValue == .completed {
                completedAt = completedAt ?? Date()
            } else {
                completedAt = nil
            }
        }
    }

    var petName: String {
        pet?.name ?? "Unassigned Pet"
    }

    /// Updates status automatically based on scheduled date unless the entry was manually marked completed.
    /// Returns true if the status changed.
    @discardableResult
    func refreshAutomaticStatus() -> Bool {
        guard status != .completed else {
            return false
        }

        let computedStatus: CareStatus = scheduledDate.isTodayOrFuture ? .scheduled : .overdue
        if status != computedStatus {
            status = computedStatus
            return true
        }
        return false
    }
}
