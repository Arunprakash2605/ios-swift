import SwiftUI

/// Categories of pet care activities tracked in PetCare.
enum CareCategory: String, CaseIterable, Codable, Identifiable {
    case vaccination = "Vaccination"
    case vetVisit = "Vet Visit"
    case grooming = "Grooming"
    case diet = "Diet"

    var id: String { rawValue }

    var iconName: String {
        switch self {
        case .vaccination: return "syringe.fill"
        case .vetVisit: return "stethoscope"
        case .grooming: return "scissors"
        case .diet: return "fork.knife"
        }
    }

    var tintColor: Color {
        switch self {
        case .vaccination: return AppColors.vaccinationTint
        case .vetVisit: return AppColors.vetVisitTint
        case .grooming: return AppColors.groomingTint
        case .diet: return AppColors.dietTint
        }
    }
}

/// Lifecycle status of a care or vaccination entry.
enum CareStatus: String, CaseIterable, Codable, Identifiable {
    case scheduled = "Scheduled"
    case completed = "Completed"
    case overdue = "Overdue"

    var id: String { rawValue }

    var iconName: String {
        switch self {
        case .scheduled: return "calendar.badge.clock"
        case .completed: return "checkmark.circle.fill"
        case .overdue: return "exclamationmark.triangle.fill"
        }
    }

    var foregroundColor: Color {
        switch self {
        case .scheduled: return AppColors.statusScheduled
        case .completed: return AppColors.statusCompleted
        case .overdue: return AppColors.statusOverdue
        }
    }

    var backgroundColor: Color {
        switch self {
        case .scheduled: return AppColors.statusScheduledBackground
        case .completed: return AppColors.statusCompletedBackground
        case .overdue: return AppColors.statusOverdueBackground
        }
    }
}
