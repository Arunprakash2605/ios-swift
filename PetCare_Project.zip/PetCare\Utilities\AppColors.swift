import SwiftUI

/// Centralized color palette and semantic design tokens for PetCare.
/// Uses a soft teal green primary theme paired with light mint accents and off-white surfaces.
enum AppColors {
    // MARK: - Brand Colors
    /// Primary soft teal green (#2A9D8F)
    static let primary = Color(red: 42 / 255, green: 157 / 255, blue: 143 / 255)
    /// Darker teal for pressed states and high-contrast text on light surfaces (#1F7A6F)
    static let primaryDark = Color(red: 31 / 255, green: 122 / 255, blue: 111 / 255)
    /// Secondary light mint (#D8F3DC)
    static let secondary = Color(red: 216 / 255, green: 243 / 255, blue: 220 / 255)
    /// Ultra-soft mint tint for icon pills and subtle highlights (#ECF9F2)
    static let mintSurface = Color(red: 236 / 255, green: 249 / 255, blue: 242 / 255)

    // MARK: - Surface & Background Colors
    /// App-wide off-white background (#F7FAF9)
    static let background = Color(red: 247 / 255, green: 250 / 255, blue: 249 / 255)
    /// Elevated card surface (#FFFFFF)
    static let cardBackground = Color.white
    /// Input field background (#F1F6F5)
    static let inputBackground = Color(red: 241 / 255, green: 246 / 255, blue: 245 / 255)
    /// Subtle divider and border stroke (#E2ECE9)
    static let border = Color(red: 226 / 255, green: 236 / 255, blue: 233 / 255)

    // MARK: - Typography Colors
    /// Primary dark slate text (#182825)
    static let textPrimary = Color(red: 24 / 255, green: 40 / 255, blue: 37 / 255)
    /// Secondary muted slate text (#5C706C)
    static let textSecondary = Color(red: 92 / 255, green: 112 / 255, blue: 108 / 255)
    /// Placeholder / tertiary text (#8FA39F)
    static let textTertiary = Color(red: 143 / 255, green: 163 / 255, blue: 159 / 255)

    // MARK: - Status Colors
    /// Scheduled status: clean medical blue (#2563EB)
    static let statusScheduled = Color(red: 37 / 255, green: 99 / 255, blue: 235 / 255)
    static let statusScheduledBackground = Color(red: 239 / 255, green: 246 / 255, blue: 255 / 255)

    /// Completed status: healthy emerald green (#16A34A)
    static let statusCompleted = Color(red: 22 / 255, green: 163 / 255, blue: 74 / 255)
    static let statusCompletedBackground = Color(red: 240 / 255, green: 253 / 255, blue: 244 / 255)

    /// Overdue status: alert coral red (#DC2626)
    static let statusOverdue = Color(red: 220 / 255, green: 38 / 255, blue: 38 / 255)
    static let statusOverdueBackground = Color(red: 254 / 255, green: 242 / 255, blue: 242 / 255)

    // MARK: - Category Accent Colors
    static let vaccinationTint = Color(red: 42 / 255, green: 157 / 255, blue: 143 / 255)
    static let vetVisitTint = Color(red: 59 / 255, green: 130 / 255, blue: 246 / 255)
    static let groomingTint = Color(red: 168 / 255, green: 85 / 255, blue: 247 / 255)
    static let dietTint = Color(red: 245 / 255, green: 158 / 255, blue: 11 / 255)

    // MARK: - Feedback Colors
    static let error = Color(red: 220 / 255, green: 38 / 255, blue: 38 / 255)
    static let warning = Color(red: 217 / 255, green: 119 / 255, blue: 6 / 255)
    static let shadow = Color.black.opacity(0.06)
}

/// Reusable card modifier matching the PetCare visual language.
struct PetCareCardModifier: ViewModifier {
    var cornerRadius: CGFloat = AppConstants.Layout.cardCornerRadius
    var padding: CGFloat = AppConstants.Layout.cardPadding

    func body(content: Content) -> some View {
        content
            .padding(padding)
            .background(AppColors.cardBackground)
            .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
                    .stroke(AppColors.border.opacity(0.7), lineWidth: 1)
            )
            .shadow(color: AppColors.shadow, radius: 10, x: 0, y: 4)
    }
}

extension View {
    /// Applies standard PetCare white rounded card styling with a subtle border and shadow.
    func petCareCard(
        cornerRadius: CGFloat = AppConstants.Layout.cardCornerRadius,
        padding: CGFloat = AppConstants.Layout.cardPadding
    ) -> some View {
        modifier(PetCareCardModifier(cornerRadius: cornerRadius, padding: padding))
    }
}
