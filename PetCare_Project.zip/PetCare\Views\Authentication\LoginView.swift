import SwiftUI

/// Root authentication container switching smoothly between Biometric Login and Manual Login.
struct LoginView: View {
    @Environment(AppState.self) private var appState
    @State private var viewModel: AuthenticationViewModel?

    var body: some View {
        Group {
            if let viewModel {
                if viewModel.showManualLogin {
                    ManualLoginContentView(viewModel: viewModel)
                        .transition(.opacity.combined(with: .move(edge: .trailing)))
                } else {
                    BiometricLoginView(viewModel: viewModel)
                        .transition(.opacity.combined(with: .move(edge: .leading)))
                }
            } else {
                ProgressView()
                    .tint(AppColors.primary)
            }
        }
        .animation(.easeInOut(duration: 0.25), value: viewModel?.showManualLogin ?? true)
        .onAppear {
            if viewModel == nil {
                viewModel = AuthenticationViewModel(appState: appState)
            } else {
                viewModel?.refreshBiometricAvailability()
            }
        }
    }
}

/// Manual email/password login and local account registration view.
private struct ManualLoginContentView: View {
    @Bindable var viewModel: AuthenticationViewModel

    var body: some View {
        ZStack {
            AppColors.background.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 22) {
                    // Header & Branding
                    VStack(spacing: 12) {
                        Image("PetCareLogo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 78, height: 78)
                            .shadow(color: AppColors.primary.opacity(0.22), radius: 12, x: 0, y: 5)

                        Text("Welcome to \(AppConstants.AppInfo.name)")
                            .font(.system(size: 27, weight: .bold, design: .rounded))
                            .foregroundStyle(AppColors.textPrimary)

                        Text("Sign in to manage your pets' vaccinations, appointments, and daily wellness.")
                            .font(.system(size: 14, weight: .regular))
                            .foregroundStyle(AppColors.textSecondary)
                            .multilineTextAlignment(.center)
                    }
                    .padding(.top, 16)

                    // Mode Switcher
                    Picker("Authentication Mode", selection: Binding(
                        get: { viewModel.authMode },
                        set: { viewModel.switchMode(to: $0) }
                    )) {
                        ForEach(AuthenticationViewModel.AuthMode.allCases) { mode in
                            Text(mode.rawValue).tag(mode)
                        }
                    }
                    .pickerStyle(.segmented)

                    // Credentials Form Card
                    VStack(spacing: 16) {
                        if viewModel.authMode == .register {
                            CustomTextField(
                                title: "Full Name",
                                placeholder: "Enter your full name",
                                text: $viewModel.fullName,
                                icon: "person.fill",
                                autocapitalization: .words,
                                errorMessage: viewModel.nameError
                            )
                        }

                        CustomTextField(
                            title: "Email Address",
                            placeholder: "name@example.com",
                            text: $viewModel.email,
                            icon: "envelope.fill",
                            keyboardType: .emailAddress,
                            autocapitalization: .never,
                            errorMessage: viewModel.emailError
                        )

                        CustomTextField(
                            title: "Password",
                            placeholder: "Minimum 6 characters",
                            text: $viewModel.password,
                            icon: "lock.fill",
                            isSecure: true,
                            autocapitalization: .never,
                            errorMessage: viewModel.passwordError
                        )

                        if let generalError = viewModel.generalErrorMessage {
                            HStack(spacing: 8) {
                                Image(systemName: "exclamationmark.circle.fill")
                                    .foregroundStyle(AppColors.error)
                                Text(generalError)
                                    .font(.system(size: 13, weight: .medium))
                                    .foregroundStyle(AppColors.error)
                            }
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(AppColors.statusOverdueBackground)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }

                        CustomButton(
                            title: viewModel.authMode == .signIn ? "Sign In" : "Create Account",
                            icon: viewModel.authMode == .signIn ? "arrow.right.circle.fill" : "person.badge.plus",
                            style: .primary
                        ) {
                            viewModel.submitManualAuthentication()
                        }

                        if viewModel.authMode == .signIn {
                            Button {
                                viewModel.fillDemoCredentials()
                            } label: {
                                HStack(spacing: 6) {
                                    Image(systemName: "sparkles")
                                    Text("Fill Default Account (\(AppConstants.DefaultAccount.email))")
                                }
                                .font(.system(size: 12, weight: .semibold, design: .rounded))
                                .foregroundStyle(AppColors.primaryDark)
                            }
                            .buttonStyle(.plain)
                            .padding(.top, 2)
                        }
                    }
                    .petCareCard(padding: 20)

                    // Biometric Fallback Option
                    if viewModel.isBiometricAvailable {
                        CustomButton(
                            title: "Sign in with \(viewModel.biometricCapability.displayName)",
                            icon: viewModel.biometricCapability.systemImageName,
                            style: .outline
                        ) {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                viewModel.showManualLogin = false
                            }
                        }
                    } else if let statusMessage = viewModel.biometricStatusMessage {
                        Label(statusMessage, systemImage: "info.circle")
                            .font(.system(size: 12, weight: .regular))
                            .foregroundStyle(AppColors.textSecondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 8)
                    }

                    Spacer(minLength: 24)
                }
                .padding(.horizontal, AppConstants.Layout.screenPadding)
            }
        }
    }
}
