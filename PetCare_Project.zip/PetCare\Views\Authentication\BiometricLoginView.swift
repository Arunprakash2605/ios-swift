import SwiftUI

/// Biometric authentication landing screen using Face ID / Touch ID via Apple's LocalAuthentication framework.
struct BiometricLoginView: View {
    @Bindable var viewModel: AuthenticationViewModel

    var body: some View {
        ZStack {
            AppColors.background.ignoresSafeArea()

            ScrollView(showsIndicators: false) {
                VStack(spacing: 26) {
                    Spacer(minLength: 28)

                    // App Logo & Welcome Copy
                    VStack(spacing: 14) {
                        Image("PetCareLogo")
                            .resizable()
                            .scaledToFit()
                            .frame(width: 92, height: 92)
                            .shadow(color: AppColors.primary.opacity(0.24), radius: 14, x: 0, y: 6)

                        Text(AppConstants.AppInfo.name)
                            .font(.system(size: 32, weight: .bold, design: .rounded))
                            .foregroundStyle(AppColors.textPrimary)

                        Text("Welcome back! Keep vaccinations, vet visits, and daily care organized in one place.")
                            .font(.system(size: 15, weight: .regular))
                            .foregroundStyle(AppColors.textSecondary)
                            .multilineTextAlignment(.center)
                            .padding(.horizontal, 12)
                    }

                    // Biometric Card
                    VStack(spacing: 18) {
                        ZStack {
                            Circle()
                                .fill(AppColors.mintSurface)
                                .frame(width: 84, height: 84)

                            Image(systemName: viewModel.biometricCapability.systemImageName)
                                .font(.system(size: 36, weight: .medium))
                                .foregroundStyle(
                                    viewModel.isBiometricAvailable ? AppColors.primary : AppColors.textSecondary
                                )
                        }

                        VStack(spacing: 6) {
                            Text("Unlock with \(viewModel.biometricCapability.displayName)")
                                .font(.system(size: 19, weight: .bold, design: .rounded))
                                .foregroundStyle(AppColors.textPrimary)

                            if let statusMessage = viewModel.biometricStatusMessage {
                                Text(statusMessage)
                                    .font(.system(size: 13, weight: .regular))
                                    .foregroundStyle(AppColors.textSecondary)
                                    .multilineTextAlignment(.center)
                            }
                        }

                        if let errorMessage = viewModel.generalErrorMessage {
                            HStack(spacing: 8) {
                                Image(systemName: "exclamationmark.triangle.fill")
                                    .foregroundStyle(AppColors.error)
                                Text(errorMessage)
                                    .font(.system(size: 13, weight: .medium))
                                    .foregroundStyle(AppColors.error)
                            }
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(AppColors.statusOverdueBackground)
                            .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
                        }

                        CustomButton(
                            title: "Authenticate with \(viewModel.biometricCapability.displayName)",
                            icon: viewModel.biometricCapability.systemImageName,
                            style: .primary,
                            isLoading: viewModel.isAuthenticating,
                            isDisabled: !viewModel.isBiometricAvailable
                        ) {
                            Task {
                                await viewModel.authenticateWithBiometrics()
                            }
                        }

                        CustomButton(
                            title: "Use Email & Password",
                            icon: "envelope.fill",
                            style: .secondary
                        ) {
                            withAnimation(.easeInOut(duration: 0.2)) {
                                viewModel.showManualLogin = true
                            }
                        }
                    }
                    .petCareCard(padding: 22)

                    Spacer(minLength: 20)
                }
                .padding(.horizontal, AppConstants.Layout.screenPadding)
            }
        }
        .onAppear {
            viewModel.refreshBiometricAvailability()
        }
    }
}
